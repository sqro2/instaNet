-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 10, 2017 at 11:15 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_data`
--

CREATE TABLE `app_data` (
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(40) NOT NULL,
  `interest` varchar(100) NOT NULL,
  `avail` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chat_notice`
--

CREATE TABLE `chat_notice` (
  `id` bigint(20) NOT NULL,
  `notice_from` varchar(50) NOT NULL,
  `notice_to` varchar(50) NOT NULL,
  `data` text NOT NULL,
  `read_yet` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `client_mail` varchar(50) NOT NULL,
  `feedback_cat` text NOT NULL,
  `msg_body` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `msg_data`
--

CREATE TABLE `msg_data` (
  `id` bigint(20) NOT NULL,
  `msg_to` varchar(50) NOT NULL,
  `b_node_name` varchar(50) NOT NULL,
  `msg_from` varchar(50) NOT NULL,
  `f_node_name` varchar(50) NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ref_links`
--

CREATE TABLE `ref_links` (
  `id` bigint(20) NOT NULL,
  `referrer` varchar(50) NOT NULL,
  `link_content` varchar(200) NOT NULL,
  `inv_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ref_notice`
--

CREATE TABLE `ref_notice` (
  `id` bigint(20) NOT NULL,
  `ref_from` varchar(50) NOT NULL,
  `ref_to` varchar(50) NOT NULL,
  `link_data` text NOT NULL,
  `read_yet` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trend_graph`
--

CREATE TABLE `trend_graph` (
  `id` bigint(20) NOT NULL,
  `topic` varchar(200) NOT NULL,
  `act_node` bigint(20) NOT NULL,
  `bool` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trend_validity`
--

CREATE TABLE `trend_validity` (
  `id` bigint(20) NOT NULL,
  `search_data` varchar(200) NOT NULL,
  `user_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(40) NOT NULL,
  `location` varchar(100) NOT NULL,
  `sex` varchar(12) NOT NULL,
  `interest` varchar(100) NOT NULL,
  `avail` varchar(10) NOT NULL,
  `tweet` text NOT NULL,
  `metaphone` varchar(200) NOT NULL,
  `url_avater` varchar(500) NOT NULL,
  `session_info` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_profile_img`
--

CREATE TABLE `user_profile_img` (
  `id` bigint(20) NOT NULL,
  `img_url` varchar(500) NOT NULL,
  `uploader` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_notice`
--
ALTER TABLE `chat_notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `msg_data`
--
ALTER TABLE `msg_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_links`
--
ALTER TABLE `ref_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref_notice`
--
ALTER TABLE `ref_notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trend_graph`
--
ALTER TABLE `trend_graph`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trend_validity`
--
ALTER TABLE `trend_validity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_profile_img`
--
ALTER TABLE `user_profile_img`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_notice`
--
ALTER TABLE `chat_notice`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `msg_data`
--
ALTER TABLE `msg_data`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ref_links`
--
ALTER TABLE `ref_links`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ref_notice`
--
ALTER TABLE `ref_notice`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trend_graph`
--
ALTER TABLE `trend_graph`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trend_validity`
--
ALTER TABLE `trend_validity`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_profile_img`
--
ALTER TABLE `user_profile_img`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
