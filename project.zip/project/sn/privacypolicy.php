<?php 
	session_start();
	require'./php/home/query_user_session.php';	
	require './php/username.php';
	require './php/home/profile_image_retrived.php';
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0'>
		<title>Privacy Policy</title>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
		<link rel='icon' type='image/png' href='http://localhost/sn/assets/images/vectors/home/cam.png'/>
		<link rel="stylesheet" href="http://localhost/sn/css/privacy_stylesheet.css">
		<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
		<script type='text/javascript' src='http://localhost/sn/js/nav_p_policy.js'></script>
	</head>
	<body>
		<div class='header'>
			<div class='header_content_wrapper'>
				<div class='header_content_wrapper_inner'>
					<ul class='header_items'>
						<li class='nav_li_log_out'>
							<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-hourglass-end' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>logout</span></a></strong> 
						</li>
						<li class='nav_bar'>
							<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-bars' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>nav_menu</span></a></strong>
						</li>
						<li>
							<strong><a href='http://localhost/sn/notifications.php'><i class='fa pull-left  fa-bell' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>notification</span></a></strong>
						</li>
					</ul>
					<ul class='header_user_data'>
						<li class='image_data'>
							<div class='user_retrived_img_container' style='background-image:url(<?php echo $avater_path ?>)'>
							</div>
						</li>
						<li class='text_data'>
							<strong>
								<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
									<?php
										echo $user_name_retrived; 
									?>
								</a>
							</strong>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class='content_wrapper_outer'>
			<div class='content_wrapper_inner'>
				<div class='section_0'>
					<div class='ul_nav_container'>
						<div class='ul_nav'>
							<ul>
								<h1 class='ul_header'>Info-Bar</h1>
								<li>
									<strong>
										<a href='http://localhost/sn/invitefriends.php'>Invite Friends</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/settings.php'>Settings</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/about.php'>About</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/faq.php'>
											
										FAQ</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/terms&conditions.php'>Terms & Conditions</a>
									</strong>
								</li>
								<li class='li_feedback'>
									<strong >
										<a href='http://localhost/sn/feedback.php'>Feedback</a>
									</strong>
								</li>							 
							</ul>
						</div>
					</div>
				</div>
				<div class='section_1'>				 
					<div class='inner_section_1'>
						<div class='page_heading'>
							<h1 id='h_content'>Privacy Policy
								<span class='h_content_span_el_1' id='h_content_span_child_1'><a href='http://localhost/sn/invitefriends.php'>Invite Friends</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/settings.php'>Settings</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/about.php'>About</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/faq.php'>Faq</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/terms&conditions.php'>Terms</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/feedback.php'>feedback</a></span>
							</h1>
						</div>
						<div class='article'>
							<div class='article_content'>
								<h3 class='article_header_1'>The informations we collect</h3>
								<p class='article_header_1_content'>We Collect The Following Informations From Users For Each Login Session</p>
								<p class='article_header_1_content_span_el'>-Your Username</p>
								<p class='article_header_1_content_span_el'>-Your Location Informations</p>
								<p class='article_header_1_content_span_el'>-Additional Informations Like Your Gender,What You Post on Thrilline And The Data Exchanged Among Users</p>

								<h3 class='article_header_2'>How Do We Use These Informations</h3>
								<p class='article_header_2_content'>We Do Not Share Users Informations With Any Third Party Products.We keep all of The Users Dsta Inside Our Database As Long As They Are Loged In.We Remove All of Their Informations When They Choose To End Their Session or Loged Out</p>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>				
