<?php
if(isset($_POST['var_str']) && isset($_POST['sub'])&&(isset($_POST['css_selector_0'])||isset($_POST['css_selector_1']))){
		$row_str=strtolower($_POST['var_str']);	
 if(isset($_POST['css_selector_0'])){ 
 				$selector_0=$_POST['css_selector_0'];
	 			if($selector_0==0){
				$search_string=["class","=","'"];
				$ini;
				$syn_modifier_search_str=array("<",">","/");
				$syn_modifier_replace_str=array("1o1","0c0","c");
				$syn_modified_str=str_replace($syn_modifier_search_str,$syn_modifier_replace_str,$row_str);
				//echo $syn_modified_str;
				//die();
				$css_string="";
				$space="[\s]{0,}";
				$pattern_0="/class[\s]{0,}=[\s]{0,}'[\w]{0,}[\s]{0,}'/";
				$pattern_1="/1o1c[^-]{1,8}0c0[\s]{0,}1o1[^-]{1,8}[\s]{0,}[^1o1c]{0,}0c0/";
				
				$m_string_0=preg_match_all($pattern_0,$syn_modified_str,$match_arrey_0);
				$m_string_1=preg_match_all($pattern_1,$syn_modified_str,$match_arrey_1);
				$val_array_0=array();
				$val_array_1=array();
				foreach($match_arrey_0[0] as $val){
					$val_array_0[]=$val;
					
				}
				
				for($ini=0;$ini<$m_string_0;$ini++){
					$css_string=$css_string." ".".".$val_array_0[$ini]." ";
					$m_string_0_1=str_replace($search_string,"",$css_string);
					echo $m_string_0_1."{}"."<br>";
					
					
				}
				foreach($match_arrey_1[0] as $val_1){
					echo $val_1;
					}

			}else{
			    header("Location: http://localhost/sn/css.php");
			}
	 
	 
	 
	 }
	 if(isset($_POST['css_selector_1'])){
		 $selector_1=$_POST['css_selector_1'];
			if($selector_1==1){
				$search_string=["id","=","'"];
				$ini;
				$css_string="";
				$pattern_0="/id[\s]{0,}=[\s]{0,}'[\w]{0,}[\s]{0,}'/";
				
				$m_string_0=preg_match_all($pattern_0,$row_str,$match_arrey_0);
				$val_array_0=array();
				foreach($match_arrey_0[0] as $val){
					$val_array_0[]=$val;
					
				}
				
				for($ini=0;$ini<$m_string_0;$ini++){
					$css_string=$css_string." "."#".$val_array_0[$ini]." ";
					$m_string_0_1=str_replace($search_string,"",$css_string);
					echo $m_string_0_1."{}"."<br>";
					
					
				}
			}else{
			    header("Location: http://localhost/sn/css.php");
			}		 
		 
		 
		 
		 
		 
		 }
	
}else{
		echo "not submitted";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	?>
	