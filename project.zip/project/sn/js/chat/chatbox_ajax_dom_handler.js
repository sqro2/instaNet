$(document).ready(function(){
var device_width=$(window).innerWidth();
if(device_width<320){
	function dom_update_ajax(){
		var front_node=$("#cl_1").val();
		var back_node=$("#cl_2").val();
		
		}
	dom_update_ajax();
	
}
})