$(document).ready(function(){
	if($(window).innerWidth()<311){
	$(".front_node_data").elastic();
	}
})