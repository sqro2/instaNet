/*$(window).load(function(){
	$("#window_close").click(function(){
	var back_node=$(".back_node").val();
	      $.ajax({
		  type: "post",
        url: "chatbox_dom_update_handler.php",
        data: {back_node:back_node},
		 success:function(data){
		       $(".chat_box_data_container_inner").append(data);
				   },
        error: function() {
          alert("an error occurd..try reloading the page");
             }				   
       });
	   });
});