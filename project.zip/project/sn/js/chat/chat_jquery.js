$(document).ready(function(){
	var device_height =($(window).innerHeight()-70);
	var device_width=$(window).innerWidth();
	var footer_height=$("#chat_box_footer_container").height();
	
	if(device_width<320){
		$("#chat_box_data_container").css("height",device_height+"px");
		//$("#up_file").click(function(){
			//$("#upload_space_wrapper").toggle();
	//});
		$("#window_close").click(function(){
			parent.closeIFrame();
		});
		
		$("#front_node_data_type_text_img").elastic();
		
	}
	if(device_width>=290 && device_width<=2200){
		$("#front_node_data_type_text_img").elastic(); 
		$("#up_file").click(function(){
			$(".upload_space_wrapper").toggle();
		});
		if(device_width>1080){
			
			$("#chat_box_data_container").css("height",((device_height-footer_height)-40)+"px");
			var top_scroll=$(".chat_box_data_container")[0].scrollHeight;
			$(".chat_box_data_container").scrollTop(top_scroll);
		}
		
	}
	
});

$(window).load(function(){
	var device_width_on_load=$(window).innerWidth();
    if(device_width_on_load>290){
	    var top_scroll=$(".chat_box_data_container")[0].scrollHeight;
	$(".chat_box_data_container").scrollTop(top_scroll);
	//alert(top_scroll);
	}
	});	