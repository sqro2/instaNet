$(document).ready(function(){
  var media_viewport_width=$(window).innerWidth();
  if(media_viewport_width<768){
	  $(".nav_bar").show();
  }
});