$(document).ready(function(){
	$("#u_name").keyup(function(){
		var u_name=$("#u_name").val();
		$.post('./php/index/index_validation_ajax.php', {name:u_name,}, function(data){
				$("#global_r_r").html(data);
		});
	});
});