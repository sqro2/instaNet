$("document").ready(function(){
	    	var viewport_width=$(window).outerWidth();
	        var section_2_width=$("#section_2").width();
	        var section_2_margin=((viewport_width-section_2_width)/2)+"px";
            if(viewport_width>319 && viewport_width<850 ){
			$("#section_2").css("margin-left",section_2_margin);
			
		 }	
});
$(window).resize(function(){
	    	var viewport_width=$(window).outerWidth();
	        var section_2_width=$("#section_2").width();
	        var section_2_margin=((viewport_width-section_2_width)/2)+"px";
            if(viewport_width>319 && viewport_width<850 ){
			$("#section_2").css("margin-left",section_2_margin);
			
		 }	
	});