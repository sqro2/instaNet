$(document).ready(function(){
  var media_viewport_width=$(window).outerWidth();
  var u_img_container_width=$(".u_img_container_inner").width();
  var per_section_0_width=16.11;
  var per_section_1_width=36.603;
  var per_section_2_width=21.96;
  var per_section_3_width=16.11;
  var per_global_search_container_width=36.45;
  var per_db_qurey_box_wrapper_width=34.11;
  var per_search_bar_input_width=32.94;
  var per_sub_heading_1_width=30.38;
  var per_cell_icon_png_width=3.29;
  var per_search_bar_input_width=32.94;
  /*elements responsive_widths*/
  var section_0_width=parseInt((per_section_0_width*media_viewport_width)/100);
  var section_1_width=parseInt((per_section_1_width*media_viewport_width)/100);
  var section_2_width=parseInt((per_section_2_width*media_viewport_width)/100);
  var section_3_width=parseInt((per_section_3_width*media_viewport_width)/100);
  var global_search_container_width=parseInt((per_global_search_container_width*media_viewport_width)/100);
  var db_qurey_box_wrapper_width=parseInt((per_db_qurey_box_wrapper_width*media_viewport_width)/100);
  var sub_heading_1_width=parseInt((per_sub_heading_1_width*media_viewport_width)/100);
  var cell_icon_png_width=parseInt((per_cell_icon_png_width*media_viewport_width)/100);
  if(media_viewport_width>1080){
 $(".section_0").css({
	  "width":section_0_width+"px",
	 });
 $(".section_1").css({
	  "width":section_1_width+"px",
	 });
 $(".section_2").css({
	  "width":section_2_width+"px",
	 });
 $(".section_3").css({
	  "width":section_3_width+"px",
	 });
 $(".global_search_container_wrapper").css({
	  "width":global_search_container_width+"px",
	 });
 $(".db_qurey_box_wrapper").css({
	  "width":db_qurey_box_wrapper_width+"px",
	 });
// $(".sub_heading_1").css({
	//  "width":sub_heading_1_width+"px",
	// });
 //$(".cell_icon_png").css({
	 // "width":cell_icon_png_width+"px",
  //});	 
  }
});
$(document).ready(function(){

});