
$(window).load(function(){
	$("#load").click(function(){
		var rowcount_final = parseInt($("#query_id_final").val());
		        $.ajax({

		  type: "post",
        url: "sf_query_handler_ajax.php",
        data: {r_count_final:rowcount_final,},
		  beforeSend:function(){
			$(".anime_preload_2").show();
		},
		complete:function(){
			$(".anime_preload_2").hide();
		},
		 success:function(data){
				   $(data).appendTo(".chell_container_inner");
				  
				   },
        error: function() {
          alert("an error occurd..try reloading the page");
             }, 
		 
       });	
	
	});
});
