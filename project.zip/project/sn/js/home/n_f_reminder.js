$(document).ready(function(){
		$.get("../n_f_reminder_ajax.php",function(data){
			if(data>0){
				$("#n_f_icon").css({
					"color":"#FE4C48",
					"text-shadow":"0px 0px 5px #ccc",
				});
				$("#n_f_data_counter").html('('+data+')');
				}else{
				$("#n_f_icon").css({
					"color":"#4F707B",
					"text-shadow":"",
				});
				$("#n_f_data_counter").html('');
				
			}
			
		});	
	
	
	

	setInterval(function(){
		$.get("../n_f_reminder_ajax.php",function(data){
			if(data>0){
				$("#n_f_icon").css({
					"color":"#FE4C48",
					"text-shadow":"0px 0px 5px #ccc",
				});
				$("#n_f_data_counter").html('('+data+')');
				}else{
				$("#n_f_icon").css({
					"color":"#4F707B",
					"text-shadow":"",
				});
				$("#n_f_data_counter").html('');
				
			}
			
		});
		
	},10000);
	
});