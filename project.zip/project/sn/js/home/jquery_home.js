$(document).ready(function(){
	if($(window).innerWidth()>1080){
	var width_0=$(".section_0").width();
	var width_1=$(".section_1").width();
	var width_2=$(".section_2").width();
	var width_3=$(".global_search_container_wrapper").width();
	var height_0=$(".global_search_container_wrapper").height();
	var new_width_0=(width_0+20)+"px";
	var new_width_1=(width_0+width_1+width_2+80)+"px";
	$(".section_1").css({
		"margin-left":new_width_0,
	});
	$(".u_img_container").css({
		"height":height_0+"px",
		"width":((width_3*30)/100)+"px",
	});
}
if($(window).innerWidth()>1080){
$(".u_img_container").mouseover(function(){
       $("#user_profile_img_post").fadeIn("1000");
	});
$("#user_profile_img_post").click(function(event){
       $("#user_profile_img_browse").click();
	   event.preventDefault();
	});	
	   $("#user_profile_img_browse").change(function(){
	   $("#user_profile_img_post").attr("value","Upload");
	   $("#user_profile_img_post").unbind();
	   });	
	}
});
$(window).resize(function(){
	if($(window).innerWidth()>1080){
	var width_0=$(".section_0").width();
	var new_width_0=(width_0+20)+"px";
	$(".section_1").css({
		"margin-left":new_width_0,
	});
	}
});
$(document).ready(function(){
	if($(window).innerWidth()<=1080){
	$(window).scroll(function(){
		var scroll_top=$(window).scrollTop();
       if(scroll_top>90){
		   $(".section_3").css({
			   "top":"10px"
		   });
	   }
	  if(scroll_top<=60){
		   $(".section_3").css({
			   "top":"95px"
		   });		  
	  }
	});
	}
});
$(document).ready(function(){
	//$(".form_tweet").attr("placeholder","write something describing your search (optional)").css({"border":"1px solid #ccc","outline":"0px","margin-top":"5px","margin-left":"0px","font-family":"verdana","font-size":"11px","padding-left":"0px"});
});
$(document).ready(function(){
	$("#search_bar_input_tweet").focus(function(){
		$(this).elastic();
	});
       $("#image_picker_button_browse").click(function(){
		   $(".image_picker_wrapper").toggle();
	   });
$("#user_name_update_quick").click(function(){
	$("#quick_settings_wrapper").fadeIn("2000",function(){
		$("body").css("overflow","hidden");
		});
		 $("#header_space_location").hide();
		 $("#header_space_gender").hide();
             $("#update_space_location").hide();
		$("#update_space_gender").hide();
		 $("#update_space_name").show();
		 $("#header_space_name").show();
	});
	$("#update_location_on_click").click(function(){
	$("#quick_settings_wrapper").fadeIn("2000",function(){
		$("body").css("overflow","hidden");
		});
		$("#header_space_name").hide();
		$("#update_space_name").hide();
		$("#update_space_gender").hide();
		 $("#header_space_gender").hide();
		$("#header_space_location").show();
             $("#update_space_location").show();
	});
	$("#update_gender_on_click").click(function(){
	$("#quick_settings_wrapper").fadeIn("2000",function(){
		$("body").css("overflow","hidden");
		});
		$("#header_space_name").hide();
		$("#update_space_name").hide();
		 $("#header_space_gender").show();
		$("#update_space_gender").show();
		$("#header_space_location").hide();
             $("#update_space_location").hide();
	});
$("#exit_quick_settings_b1").click(function(){
	$("#quick_settings_wrapper").hide();
		$("body").css("overflow","auto");
		$("#name_update_picker").val("");
		$("#on_sucess_data").html("");
	});
$("#exit_quick_settings_b2").click(function(){
	$("#quick_settings_wrapper").hide();
		$("body").css("overflow","auto");
		$("#name_update_picker").val("");
		$("#on_sucess_data").html("");
	});
$("#exit_quick_settings_b3").click(function(){
	$("#quick_settings_wrapper").hide();
		$("body").css("overflow","auto");
		$("#name_update_picker").val("");
		$("#on_sucess_data").html("");
	});
});



























