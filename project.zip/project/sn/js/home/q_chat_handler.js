$(document).ready(function(){
	$(".redirect").click(function(){
       var end_user_id=$(this).attr('id');
	   var fron_user_id=$("#f_e_data").val();
	   
	   
		});
	
})