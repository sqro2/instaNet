$(window).load(function(){
	$("#name_update_picker_post").click(function(){
		var updated_name = $("#name_update_picker").val();
		$.ajax({
			type: "post",
			url: "update_name_qs.php",
			data:{updated_name:updated_name},
			beforeSend:function(){
				$("#on_load").show();
				},
			complete:function(){
				$("#on_load").hide();
				},
	             success:function(data){
					 $("#on_sucess_data").html(data);
					 },
			error:function(){
				alert("an error occured.Try reloading the page");
				}
			
			});
		});
	
	$("#location_update_picker_post").click(function(){
		var raw_location_data = $("#location_update_picker").val();
		$.ajax({
			type: "post",
			url: "update_location.php",
			data:{raw_location_data:raw_location_data},
			beforeSend:function(){
				$("#on_load").show();
				},
			complete:function(){
				$("#on_load").hide();
				},
	             success:function(data){
					 $("#on_sucess_data").html(data);
					 },
			error:function(){
				alert("an error occured.Try reloading the page");
				}
			
			});
		});
		$("#gender_update_picker_post").click(function(){
		var raw_gender_data = $("#gender_update_picker").val();
		$.ajax({
			type: "post",
			url: "update_gender.php",
			data:{raw_gender_data:raw_gender_data},
			beforeSend:function(){
				$("#on_load").show();
				},
			complete:function(){
				$("#on_load").hide();
				},
	             success:function(data){
					 $("#on_sucess_data").html(data);
					 },
			error:function(){
				alert("an error occured.Try reloading the page");
				}
			
			});
		});
	
	
	});