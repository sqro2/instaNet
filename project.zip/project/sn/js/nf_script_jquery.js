$(document).ready(function(){
	if($(window).innerWidth()>810){
		var header_height=$("#header").height();
	    $("#notification_wrapper").css({
			"top":(header_height+3)+"px",
			"right":"10px"
		});
	
	$("#hyperlink_notification").click(function(event){
		event.preventDefault();
		if($("#notification_wrapper").css('display')=='none'){
			$("#notification_wrapper").show();
			$("#notification_wrapper").css({
				"display":"table"
			});
			var ini_data="true";
			$.ajax({
				type: "post",
				url: "../notification_script_ajax.php",
				data:{ini_data:ini_data},
				beforeSend:function(){
					$("#notification_content_ul").append("<div style='text-align:center'><i class='fa fa-circle-o-notch fa-spin' id='preloader_notification' style='color:#888888'></i></div>");
				},
				complete:function(){
					$("#preloader_notification").remove();
				},
				success:function(data){
			        if(!$.trim(data)){
						$("#notification_content_ul").append("<p style='font-size:12px;line-height:14px' id='n_w_ul_li'><i class='fa fa-pull-left fa-bell-slash-o' style='line-height:14px;color:#DE5957' ></i>No Data Found</p>");
					}
					else{
						$("#notification_content_ul").html(data);		
					}
				},
				error:function(){
					alert("an error occured.Try reloading the page");
				}
			});	
		}else{
			$("#n_w_ul_li").remove();
			$("#notification_wrapper").hide();
		}
		
	});
	}

});