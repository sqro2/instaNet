<?php   
   session_start();	
	require'./php/home/query_user_session.php';
        require './php/home/db_connect.php';
	require './php/home/retrive_location.php';
	require './php/username.php';
	require './php/settings_script.php';
	require './php/home/profile_image_retrived.php';

?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0'>
		<title>Settings</title>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
		<link rel='icon' type='image/png' href='http://localhost/sn/assets/images/vectors/home/cam.png'/>
		<link rel="stylesheet" href="http://localhost/sn/css/settings_stylesheet.css">
		<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
		<script type='text/javascript' src='http://localhost/sn/js/nav_feedback.js'></script>
	</head>
	<body>
		<div class='header'>
			<div class='header_content_wrapper'>
				<div class='header_content_wrapper_inner'>
					<ul class='header_items'>
						<li class='nav_li_log_out'>
							<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-hourglass-end' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>logout</span></a></strong> 
						</li>
						<li class='nav_bar'>
							<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-bars' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>nav_menu</span></a></strong>
						</li>
						<li>
							<strong><a href='http://localhost/sn/notifications.php'><i class='fa pull-left  fa-bell' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>notification</span></a></strong>
						</li>
					</ul>
					<ul class='header_user_data'>
						<li class='image_data'>
							<div class='user_retrived_img_container' style='background-image:url(<?php echo $avater_path ?>)'>
							</div>
						</li>
						<li class='text_data'>
							<strong>
								<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
									<?php 
										   echo $user_name_retrived;
								    ?>
								</a>
								</strong>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class='content_wrapper_outer'>
			<div class='content_wrapper_inner'>
				<div class='section_0'>
					<div class='ul_nav_container'>
						<div class='ul_nav'>
							<ul>
								<h1 class='ul_header'>Info-Bar</h1>
								<li>
									<strong>
										<a href='http://localhost/sn/invitefriends.php'>Invite Friends</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/about.php'>About</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/faq.php'>FAQ</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/privacypolicy.php'>
											
										Privacy</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/terms&conditions.php'>Terms & Conditions</a>
									</strong>
								</li>
								<li class='li_feedback'>
									<strong >
										<a href='http://localhost/sn/feedback.php'>Feedback</a>
									</strong>
								</li>							 
							</ul>
						</div>
					</div>
				</div>
				<div class='section_1'>				 
					<div class='inner_section_1'>
						<div class='page_heading'>
							<h1 id='h_content'>Settings<span class='h_content_span_el_1' id='h_content_span_child_1'><a href='http://localhost/sn/invitefriends.php'>Invite Friends</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/faq.php'>Faq</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/about.php'>About</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/privacypolicy.php'>Privacy Policy</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/terms&conditions.php'>Terms</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/feedback.php'>feedback</a></span>
							</h1>
						</div>
						<div class='article'>
							<div class='article_content'>
								<h3 class='article_header_1'>Change Username</h3>
								<p class='article_header_1_content'></p>
								<div class='inner_article_form_wrapper'>
									<form method='post' action='settings.php' class='value_update_listener'>
										<p><input type='text' placeholder='Choose a Username' class='update_value_name' name='update_value_name'/></p>
										<p><input type='submit' value='Update Username' class='update_value_name_post' name='update_value_name_post'/></p>
									</form>
								</div>
								<h3 class='article_header_1'>Your Detected Location is [<?php echo $retrived_location ?>]</h3>
								<p class='article_header_1_content'>If you think detected location does not represent your actual location feel free to edit and update</p>
								<div class='inner_article_form_wrapper'>
									<form method='post' action='settings.php' class='value_update_listener'>
										<p><input type='text' placeholder='Location' class='update_value_location' name='update_value_location'/></p>
										<p><input type='submit' value='Update Location' class='update_value_location_post' name='update_value_location_post'/></p>
									</form>
								</div>
								<h3 class='article_header_1'>Edit Gender</h3>
								<div class='inner_article_form_wrapper'>
									<form method='post' action='settings.php' class='value_update_listener'>
										<select class='settings_gender_update' id='settings_gender_update' name='setting_gender_update'>
										   <option class='s_g_u_options' value='male'>Male</option>
										   <option class='s_g_u_options' value='female'>Female</option>
										</select>
								        <p><input type='submit' value='Update gender' class='update_value_gender_post' name='update_value_gender_post'/></p>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>										
