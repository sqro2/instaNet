
<!doctype html>
<?php 
	session_start();
	require'./php/home/query_user_session.php';
	require './php/db_connect.php';
	require './php/username.php';
?>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0'>
		<title>Notifications</title>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
		<link rel="stylesheet" href="http://localhost/sn/css/n_f_stylesheet.css">
		<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
	</head>
	<body>
		<div class='header'>
			<div class='header_content_wrapper'>
				<div class='header_content_wrapper_inner'>
					<ul class='header_items'>
						<li class='nav_li_log_out'>
							<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-hourglass-end' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>logout</span></a></strong> 
						</li>
						<li class='nav_bar'>
							<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-bars' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>nav_menu</span></a></strong>
						</li>
						<li>
							<strong><a href='http://localhost/sn/notifications.php'><i class='fa pull-left  fa-bell' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>notification</span></a></strong>
						</li>
					</ul>
					<ul class='header_user_data'>
						<li class='image_data'>
							<div class='user_retrived_img_container' style='background-image:url(<?php echo $avater_path ?>)'>
							</div>
						</li>
						<li class='text_data'>
							<strong>
							<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
							      <?php echo $user_name_retrived; ?>
							</a></strong>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class='content_wrapper_outer'>
			<div class='content_wrapper_inner'>
				<div class='section_1'>				 
					<div class='inner_section_1'>
						<div class='article'>
							<div class='article_content'>
						     <ul style='padding:8px;margin:0px;width:80%'>
							 <?php
							    require './php/notification_script.php';
							 ?>
							  </ul>	
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>				
