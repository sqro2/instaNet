<?php 
	session_start();
	require'./php/home/query_user_session.php';	
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0'>
		<title>Faq</title>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
		<link rel='icon' type='image/png' href='http://localhost/sn/assets/images/vectors/home/cam.png'/>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/nav_header.css'/>
		<link rel="stylesheet" href="http://localhost/sn/css/faq_stylesheet.css">
		<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
		<script type='text/javascript' src='http://localhost/sn/js/nav_faq.js'></script>
	</head>
	<body>
		<div class='header'>
			<div class='header_content_wrapper'>
				<div class='header_content_wrapper_inner'>
					<ul class='header_items'>
						<li class='nav_li_log_out'>
							<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-hourglass-end' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>logout</span></a></strong> 
						</li>
						<li class='nav_bar'>
							<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-bars' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>nav_menu</span></a></strong>
						</li>
						<li>
							<strong><a href='http://localhost/sn/notifications.php'><i class='fa pull-left  fa-bell' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>notification</span></a></strong>
						</li>
					</ul>
					<ul class='header_user_data'>
						<li class='image_data'>
							<div class='user_retrived_img_container'>
							</div>
						</li>
						<li class='text_data'>
							<strong>
								<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
									<i class='fa pull-left  fa-user' style='color:#1B5E1D;font-size:2em;line-height:60px' id='avater_head'></i>
									<?php require './php/username.php'; 
										    echo $user_name_retrived;
									?>
								</a>
							</strong>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class='content_wrapper_outer'>
			<div class='content_wrapper_inner'>
				<div class='section_0'>
					<div class='ul_nav_container'>
						<div class='ul_nav'>
							<ul>
								<h1 class='ul_header'>Info-Bar</h1>
								<li>
									<strong>
										<a href='http://localhost/sn/invitefriends.php'>Invite Friends</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/settings.php'>Settings</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/about.php'>About</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/privacypolicy.php'>
											
										Privacy</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/terms&conditions.php'>Terms & Conditions</a>
									</strong>
								</li>
								<li class='li_feedback'>
									<strong >
										<a href='http://localhost/sn/feedback.php'>Feedback</a>
									</strong>
								</li>							 
							</ul>
						</div>
					</div>
				</div>
				<div class='section_1'>				 
					<div class='inner_section_1'>
						<div class='page_heading'>
							<h1 id='h_content'>FAQ
								<span class='h_content_span_el_1' id='h_content_span_child_1'><a href='http://localhost/sn/invitefriends.php'>Invite Friends</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/settings.php'>Settings</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/about.php'>About</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/privacypolicy.php'>Privacy Policy</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/terms&conditions.php'>Terms</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/feedback.php'>feedback</a></span>
							</h1>
						</div>
						<div class='article'>
							<div class='article_content'>
								<h3 class='article_header_1'>what is Thrilline</h3>
								<p class='article_header_1_content'>Thrilline is a online instant networking site where people can find and connect with people with same interest.In thrilling we dont keep online members</p>
								<h3 class='article_header_2'>Our goal</h3>
								<p class='article_header_2_content'>Our goal is to provide users the freedom ans apportunaty to communicate with others with same interest.Here you don't have to go through the sign up process to find others</p>
								<h3 class='article_header_3'>The team</h3>
								<p class='article_header_3_content_1'><span class='article_span_el_1'>Founder and CEO: </span><span class='article_span_el_2'>Akshay Bordoloi</span></p>
								<p class='article_header_3_content_2'><span class='article_span_el_3'>Co-founder and CFO: </span><span class='article_span_el_4'>Chinmoy Saikia</span></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>				
