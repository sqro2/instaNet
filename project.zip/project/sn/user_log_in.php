<!DOCTYPE html>
<html>
	<?php
	    //require 'php/geo.php';
		require './php/index/index_validation.php';
	?>
	<head>
	    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
	    <link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/index/index_stylesheet.css'/>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/index/index_stylesheet_responsive.css'/>
		<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
		<script type='text/javascript' src='http://localhost/sn/js/index/index_ajax_validation.js'></script>
		<script type='text/javascript' src='http://localhost/sn/js/index/index_jquery.js'></script>
	</head>
	<body>
		<div class='header'>
		</div>
		<div class='nav_header'>
		    <div class='page_banner_header'>
				<div class='inner_page_header_type_banner'>
				    <h1>Welcome to <span class='main_header_child_1'>Thrill<span> <span class='main_header_child_2'>  find your friends for the moment<span></h1>
					</div>
					</div>
					</div>
					<div class='content_wrapper_outer'>
						<div class='content_wrapper_inner'>
							<div class='section_0'>
								<div class='inner_section_0'>
									<div class='quick_intro'>
										<h3 class='section_1_header_1'>
											Quick Info
										</h3>
										<div class='content_wrapper_type_article'>
											here's some article
										</div>
									</div>
								</div>
							</div>
							<div class='section_1'>
							  <div class='inner_section_1'>
							    <div class='arrow_indicator_to_right'>
								</div>
							  </div>
							</div>
							<div class='section_2' id='section_2'>
							    <div class='inner_section_2'>
								    <div class='form_content_wrapper'>
									    <form action='user_log_in.php' method='post'>
										  <div class='global_r_r' id='global_r_r'></div>
										    <div class='input_group_container'>
											   <div class='input_type_text'><input type='text' name='u_name' id='u_name' class='u_name' placeholder='Choose your usename'/></div>
											    <div class='input_type_select' name='select_gender'><select class='gender_options' name='gender_options'>
											      <option class='g_o_value'>
												    male
												  </option>
											      <option class='g_o_value'>
												    female
												  </option>
											   </select>
											  </div>
											</div>
										<p><input type='submit' value='Get In' name='form_data' class='button_sub' id='button_sub'/></p>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
							<div class='page_footer_outer'>
								<div class='page_footer_inner'>
									<div class='footer_header_content'>
										<center><a href='http://localhost/sn/about.php'><strong>About</strong></a></center>
									</div>
								</div>
							</div>
					</body>
					</html>									
