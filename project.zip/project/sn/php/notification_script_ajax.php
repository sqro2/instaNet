<?php
	session_start();
	require 'username.php';
	
	if(isset($_POST['ini_data'])){
		$bool=0;
		$n_q_1=$dbconnect->query("SELECT * FROM chat_notice WHERE notice_to='$user_primary_id_retrived' AND read_yet='$bool' ");
		if($n_q_1->rowCount()==0){
			//echo "<h1><i class='fa fa-pull-left fa-bell-slash-o fa-2x' style='line-height:inherit;font-weight:bolder;color:#DE5957' ></i> No Notification Found!</h1>";
		}
		else{
			
			while($n_q_1_data=$n_q_1->fetch()){
				$notice_data_retrived=$n_q_1_data['data'];	
				$notice_data_sender=$n_q_1_data['notice_from'];
				$n_d_s_q_1=$dbconnect->query("SELECT username FROM users WHERE id='$notice_data_sender' ");
				while($n_d_s_q_1_data=$n_d_s_q_1->fetch()){
					$sender_name_retrived=$n_d_s_q_1_data['username'];
					echo "<li style='list-style:none;padding-top:2px;height:30px;border-bottom:1px solid #ccc;width:95%' id='n_w_ul_li'> <strong style='line-height:30px;font-size:14px;color:#35404F;'><i class='fa fa-pull-left fa-envelope' style='line-height:30px;color:#5F87C5'></i><a href='$notice_data_retrived' style='text-decoration:none;color:#575757'><span style='color:#0D406F'>$sender_name_retrived</span> sent you a message have a look</a></strong> </li>";
					//$n_q_2=$dbconnect->prepare("UPDATE chat_notice SET read_yet=:read_yet WHERE notice_to='$user_primary_id_retrived' ");
					//$n_q_2->bindValue(':read_yet',1);
					//$n_q_2->execute();
				}
				
			}
		}
		}else{
		
	}
	
?>