<?php

require'db_connect.php';

if(isset($_POST['name'])){
	$name=$_POST['name'];
	$query_index_validation=$dbconnect->query("SELECT * FROM users WHERE username='$name' ");
	$index_query_count=$query_index_validation->rowCount();
	if($index_query_count>=1){
	echo "<strong>this username is already taken.Try a differnt one</strong>";
	}
}
?>