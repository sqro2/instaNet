<?php 
	session_start();
	require'db_connect.php' ;
	$session_id_fragment=mt_rand(100000,2147423647);
    if(isset($_GET['inv_id'])){
		$back_node=$_GET['inv_id'];
		$referrer_validation=$dbconnect->query("SELECT * FROM ref_links WHERE inv_id='$back_node'");
		$referrer_validation_count=$referrer_validation->rowCount();
			if($referrer_validation_count>0){
			    while($row=$referrer_validation->fetch()){
				$link_content=$row['link_content'];
			    }
				
			  if(isset($_POST['u_name'])&& isset($_POST['gender_options'])){
				  
					$user_name=$_POST['u_name'];
				    $user_sex=$_POST['gender_options'];
				    $user_country='NA';			  
                    if(!empty($user_name)&&!empty($user_sex)){
					    $query_index_validation=$dbconnect->query("SELECT * FROM users WHERE username='$user_name' ");
					     $index_query_count=$query_index_validation->rowCount();
					     if($index_query_count==1){
						        die("<div id='page_error'><h1>Sorry user with that name already exists.Please use a different name</h1></div>");
						      }else{
									$query_insert_data=$dbconnect->prepare("INSERT INTO users (username,location,sex,avail) VALUES (:u_name,:u_location,:u_sex,:avail)");
						            $query_insert_data->bindValue(':u_name',$user_name);
						            $query_insert_data->bindValue(':u_sex',$user_sex);
						            $query_insert_data->bindValue(':u_location',$user_country);
						            $query_insert_data->bindValue(':avail','false');
						            $query_insert_data->execute();
						               $_SESSION["user_data"]=$user_name.$session_id_fragment;
						               $_final_session_id=$_SESSION["user_data"];
						                        if(isset($_SESSION["user_data"])){
							                         $set_session_id=$dbconnect->prepare("UPDATE users set session_info=:session_id, url_avater=:url_avater WHERE username='$user_name'");
							                         $set_session_id->bindValue(':session_id',$_final_session_id);
							                         $set_session_id->bindValue(':url_avater','http://localhost/sn/assets/images/maria.jpg');
							                         $set_session_id->execute();
							                         $set_user_profile_img=$dbconnect->prepare("INSERT INTO user_profile_img(img_url,uploader) VALUES(:img_url,:uploader)");
							                         $set_user_profile_img->bindValue(':img_url','http://localhost/sn/assets/images/maria.jpg');
							                         $set_user_profile_img->bindValue(':uploader',$_final_session_id);
							                         $set_user_profile_img->execute();
							                           $front_node=$_final_session_id;
							                           $f_ref_table_update_query=$dbconnect->prepare("INSERT INTO ref_notice (ref_to,ref_from,link_data,read_yet) VALUES(:ref_to,:ref_from,:link_data,:read_yet)");
							                           $f_ref_table_update_query->bindValue(':ref_to',$front_node);
							                           $f_ref_table_update_query->bindValue(':ref_from',$back_node);
							                           $f_ref_table_update_query->bindValue(':link_data',$link_content);
							                           $f_ref_table_update_query->bindValue(':read_yet','false');
							                           $f_ref_table_update_query->execute();
							                     }else{
							                         die("something went wrong");
						                               }
													   
							                    header ('location: http://localhost/sn/php/home/home.php?p_n=1');
							  }
						
						
						
						
						}else{
						die("<div id='page_error'><h1>Please fill up the form below</h1></div>");
						}
				  
				  }else{
				  }	
				
			

			}else{
			die("<strong>The reffaral link is not valid anymore</strong>");
			}
		
		}else{
		if(isset($_POST['u_name'])&& isset($_POST['gender_options'])&& isset($_POST['form_data'])){
			
			$user_name=$_POST['u_name'];
			$user_sex=$_POST['gender_options'];
			$user_country='NA';
			if(!empty($user_name)&&!empty($user_sex)){
				$query_index_validation=$dbconnect->query("SELECT * FROM users WHERE username='$user_name' ");
				$index_query_count=$query_index_validation->rowCount();
				if($index_query_count==1){
					echo "<div id='page_error'><h1>Sorry user with that name already exists.Please use a different name</h1></div>";
					}else{
					$query_insert_data=$dbconnect->prepare("INSERT INTO users (username,location,sex,avail) VALUES (:u_name,:u_location,:u_sex,:avail)");
					$query_insert_data->bindValue(':u_name',$user_name);
					$query_insert_data->bindValue(':u_sex',$user_sex);
					$query_insert_data->bindValue(':u_location',$user_country);
					$query_insert_data->bindValue(':avail','false');
					$query_insert_data->execute();
					$_SESSION["user_data"]=$user_name.$session_id_fragment;
					$_final_session_id=$_SESSION["user_data"];
					$set_session_id=$dbconnect->prepare("UPDATE users set session_info=:session_id, url_avater=:url_avater WHERE username='$user_name'");
					$set_session_id->bindValue(':session_id',$_final_session_id);
					$set_session_id->bindValue(':url_avater','http://localhost/sn/assets/images/maria.jpg');
					$set_session_id->execute();
					$set_user_profile_img=$dbconnect->prepare("INSERT INTO user_profile_img(img_url,uploader) VALUES(:img_url,:uploader)");
					$set_user_profile_img->bindValue(':img_url','http://localhost/sn/assets/images/maria.jpg');
					$set_user_profile_img->bindValue(':uploader',$_final_session_id);
					$set_user_profile_img->execute();
					header ('location: http://localhost/sn/php/home/home.php?p_n=1');
				}
				
				}else{
				echo "<div id='page_error'><h1>Please fill up the form below</h1></div>";
			}
			}else{
		
		}		
		
		
		
		
	}
?>