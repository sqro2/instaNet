
<?PHP
try{
$dbconnect = new  PDO('mysql:host=localhost; dbname=chat', 'root',  '');

}
catch(Exception $e){
	
	//echo $e->getMessage();
	echo "Problem With network Try again Later";
}
?>