<?php 
	$node_ip=$_SERVER['REMOTE_ADDR'];
	$location_data=unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$node_ip"));
	$country=strtolower($location_data["geoplugin_countryName"]);
	$region=$location_data["geoplugin_regionName"];
	//$city=$location_data["geoplugin_city"];
	if($country=='india'){
		die("Oops!!something went wrong");
		}
	
	
	//112.79.38.90
	
	
?>	