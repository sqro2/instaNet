<?php 
	require './php/home/query_user_session.php';
	require './php/db_connect.php';
	if(isset($_POST['user_name'])&&isset($_POST['client_mail'])&&isset($_POST['msg_body'])&&isset($_POST['feedback_post'])){
		$user_name=$_POST['user_name'];
		$client_mail=$_POST['client_mail'];
		$sub=$_POST['feedback_category'];
		$msg_body=$_POST['msg_body'];
		$sub_data=$_POST['feedback_post'];
		$db_row_count_query=$dbconnect->query("SELECT * FROM feedback WHERE username='$user_name' AND client_mail='$client_mail' AND msg_body='$msg_body'");
		if($db_row_count_query->rowCount()==1){
			
			}else{
			$db_insert_query=$dbconnect->prepare("INSERT INTO feedback(username,client_mail,feedback_cat,msg_body) VALUES(:username,:client_mail,:feedback_cat,:msg_body)");
			$db_insert_query->bindValue(':username',$user_name);
			$db_insert_query->bindValue(':client_mail',$client_mail);
			$db_insert_query->bindValue(':feedback_cat',$sub);
			$db_insert_query->bindValue(':msg_body',$msg_body);
			$db_insert_query->execute();
			die("<strong>Hey thanks we will try to respond as soon as possible <a href='http://localhost/sn/feedback.php'>back</a></strong>");
			     
			
		}
		}else{
		
	}
	
?>
