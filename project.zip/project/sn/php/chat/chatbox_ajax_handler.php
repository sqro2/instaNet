<?php 
	require '../home/db_connect.php';
	require '../username.php';
	if(isset($_POST['form_data'])){
	    $form_data=$_POST['form_data'];
		die("hello");
		$msg_data=$_POST['msg_data'];
		$from=$user_primary_id_retrived;
		$f_node_name=$user_name_retrived;
		$b_node_name=$back_node_user_name;
		$to=$back_node;
		$msg_data_fltrd=trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $msg_data)));
		$notice_data="<a href='http://localhost/sn/php/chat/chat.php?id=$from'>$from</a>".' '.'sent you a message';

		/* variables for handling image proccessing*/
		$name=$_FILES['file']['name'];
		$suffled_name_string=strtolower(str_shuffle($name));
		$rand_int=mt_rand(10000,100000000);
		$size=$_FILES['file']['size'];
		$type=$_FILES['file']['type'];
		$extention=strtolower(substr($name, strpos($name, '.')+1));
		$updated_name=$suffled_name_string.$rand_int.'_'.$from.'_'.$rand_int.'.'.$extention;
		$tmp_name=$_FILES['file']['tmp_name'];
		$location=$_SERVER['DOCUMENT_ROOT'].'/sn/assets/uploads/chat_data/images/';
		$updated_location=str_replace('C:/xampp/htdocs','http://localhost',$location);
		$updated_url=$updated_location.$updated_name;
		$img_data="<p>$msg_data</p><a href='$updated_url'><img src='$updated_url' width='' height='' id='load_image'></img></a>";
		$link_data="<p>$msg_data</p><a href='$updated_url'>$name</a>";
		
      if(!empty($name)){
				       if($extention=='jpg'||$extention=='jpeg'||$extention=='png'||$extention=='zip'){
						     if($extention=='jpg'||$extention=='jpeg'){
								    	if(move_uploaded_file($tmp_name,$location.$updated_name)){
		                                     $msg_data_query=$dbconnect->prepare("INSERT INTO msg_data (msg_to,msg_from,data,f_node_name,b_node_name) VALUES (:to,:from,:data,:f_node_name,:b_node_name)");
		                                     $msg_data_query->bindValue(':to',$to);
		                                     $msg_data_query->bindValue(':from',$from);
											 $msg_data_query->bindValue(':f_node_name',$f_node_name);
											 $msg_data_query->bindValue(':b_node_name',$b_node_name);
		                                     $msg_data_query->bindValue(':data',$img_data);
		                                     $msg_data_query->execute();
		                                     header("location: http://localhost/sn/php/chat/chat.php?id=$to");
		
	                                             }else{
		                                            echo "upload failed";
                                                     }
								 
								                   }
							if($extention=='zip'){
                                        	if(move_uploaded_file($tmp_name,$location.$updated_name)){
		                                        $msg_data_query=$dbconnect->prepare("INSERT INTO msg_data (msg_to,msg_from,data,f_node_name,b_node_name) VALUES (:to,:from,:data,:f_node_name,:b_node_name)");
		                                        $msg_data_query->bindValue('to',$to);
		                                        $msg_data_query->bindValue('from',$from);
											    $msg_data_query->bindValue(':f_node_name',$f_node_name);
											    $msg_data_query->bindValue(':b_node_name',$b_node_name);
		                                        $msg_data_query->bindValue('data',$link_data);
		                                        $msg_data_query->execute();
		                                     header("location: http://localhost/sn/php/chat/chat.php?id=$to");
		
	                                           }else{
		                                          echo "upload failed";
                                                      }	
								
								            }
						   
						   }else{
						   die("not supported format");
						   } 
	  
	  

		  }
         	  if(empty($name)){
			     if(!empty($msg_data_fltrd)){
					 			$msg_data_query=$dbconnect->prepare("INSERT INTO msg_data (msg_to,msg_from,data,f_node_name,b_node_name) VALUES (:to,:from,:data,:f_node_name,:b_node_name)");
			                    $msg_data_query->bindValue('to',$to);
			                    $msg_data_query->bindValue('from',$from);
								$msg_data_query->bindValue(':f_node_name',$f_node_name);
								$msg_data_query->bindValue(':b_node_name',$b_node_name);
			                    $msg_data_query->bindValue('data',$msg_data_fltrd);
			                    $msg_data_query->execute();
								header("location: http://localhost/sn/php/chat/chat.php?id=$to");
					 
				}else{
				die("you cant let the message box empty");
				}
		  
		  }
	}else{
	echo "not set";
	}
	
?>