<?php   
require '../home/db_connect.php';
require '../home/profile_image_retrived.php';
if(isset($_GET['id'])&&isset($u_primary_data)){
	$from=$user_primary_id_retrived;
	$to=$_GET['id'];
	$dom_update_query=$dbconnect->query("SELECT * FROM msg_data WHERE msg_to='$to' AND msg_from='$from' UNION SELECT * FROM msg_data WHERE msg_to='$from' AND msg_from='$to' ORDER BY id ASC ");
	while($row=$dom_update_query->fetch()){
		$data=$row['data'];
		$msg_from=$row['msg_from'];
		$msg_to=$row['msg_to'];
		$front_node_user_name=$row['f_node_name'];
		$back_node_user_name=$row['b_node_name'];
		if($msg_from==$from){
			echo"<div class='chat_data_wrapper_front_node'>
                 <div class='front_node_content'>
                    <div class='avater' style='background-image:url($avater_path)'></div>
	                 <div class='data_container'>
	                    <p class='front_node_header'><strong>$front_node_user_name</strong></p>
		                 <span class='front_node_data'>$data</span>
	                 </div>
	              </div>
				<i class='fa fa-pull-left fa-reply' id='front_node_sub_head' style='color:#10B254'></i>
              </div>";
		}if($msg_from==$to){
			echo"<div class='chat_data_wrapper_back_node'>
                 <div class='back_node_content'>
                    <div class='avater' style='background-image:url($retrived_img_url_back_node)'></div>
	                 <div class='data_container'>
	                    <p class='back_node_header'><strong>$front_node_user_name</strong></p>
		                 <span class='back_node_data'>$data</p>
	                 </div>
	              </div>
              </div>";
		}
	}
	$bool=1;
	$chat_notification_query_update_1=$dbconnect->prepare("UPDATE chat_notice set read_yet=:read WHERE notice_from='$to' AND notice_to='$from'");	
	$chat_notification_query_update_1->bindValue(':read',$bool);
	$chat_notification_query_update_1->execute();
	
}else{
	
	
}

?>