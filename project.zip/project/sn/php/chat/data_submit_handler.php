<?php 
	require '../home/db_connect.php';
	require '../username.php';
	if((isset($_POST['msg_data'])||isset($_POST['msg_data_svp']))&&isset($_POST['submit'])){
		$msg_data=$_POST['msg_data'];
		$msg_data_svp=$_POST['msg_data_svp'];
	    if(!empty($msg_data_svp)){
			$msg_data=$msg_data_svp;
		}
		$from=$user_primary_id_retrived;
		$f_node_name=$user_name_retrived;
		$b_node_name=$back_node_user_name;
		$to=$back_node;
		$msg_data_fltrd=trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $msg_data)));
		//$msg_data_svp_fltrd=trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $msg_data_svp)));
		$notice_data="http://localhost/sn/php/chat/chat.php?id=$from";
		/* variables for handling image proccessing*/
		$name=strtolower($_FILES['file']['name']);
		$suffled_name_string=strtolower(str_shuffle($name));
		$rand_int=mt_rand(10000,100000000);
		$size=$_FILES['file']['size'];
		$type=$_FILES['file']['type'];
		$extention=pathinfo($name, PATHINFO_EXTENSION);//strtolower(substr($name, strpos($name, '.')+1));
		$updated_name=$suffled_name_string.$rand_int.'_'.$from.'_'.$rand_int.'.'.$extention;
		$tmp_name=$_FILES['file']['tmp_name'];
		$location=$_SERVER['DOCUMENT_ROOT'].'/sn/assets/uploads/chat_data/images/';
		$updated_location=str_replace('C:/xampp/htdocs','http://localhost',$location);
		$updated_url=$updated_location.$updated_name;
		$img_data="<p>$msg_data</p><a href='$updated_url'><img src='$updated_url' width='' height='' id='load_image'></img></a>";
		//$img_data_svp="<p>$msg_data_svp</p><a href='$updated_url'><img src='$updated_url' width='' height='' id='load_image'></img></a>";
		$link_data="<p>$msg_data</p><a href='$updated_url'>$name</a>";
		if(!empty($name)){
			if($extention=='jpg'||$extention=='jpeg'||$extention=='png'||$extention=='zip'){
				if($extention=='jpg'||$extention=='jpeg'||$extention=='png'){
					if(move_uploaded_file($tmp_name,$location.$updated_name)){
						$msg_data_query=$dbconnect->prepare("INSERT INTO msg_data (msg_to,msg_from,data,f_node_name,b_node_name) VALUES (:to,:from,:data,:f_node_name,:b_node_name)");
						$msg_data_query->bindValue(':to',$to);
						$msg_data_query->bindValue(':from',$from);
						$msg_data_query->bindValue(':f_node_name',$f_node_name);
						$msg_data_query->bindValue(':b_node_name',$b_node_name);
						$msg_data_query->bindValue(':data',$img_data);
						$msg_data_query->execute();
						//codeblocks for notification entry{n1}
						$c_n_q_1=$dbconnect->query("SELECT * FROM chat_notice WHERE notice_from='$from' AND notice_to='$to' ");
						$c_n_q_1_count=$c_n_q_1->rowCount();
						if($c_n_q_1_count==0){
							$c_n_q_2=$dbconnect->prepare("INSERT INTO chat_notice(notice_from,notice_to,data,read_yet) VALUES(:notice_from,:notice_to,:data,:read_yet) ");
							$c_n_q_2->bindValue(':notice_from',$from);
							$c_n_q_2->bindValue(':notice_to',$to);
							$c_n_q_2->bindValue(':data',$notice_data);
							$c_n_q_2->bindValue(':read_yet',0);
							$c_n_q_2->execute();
						}
						if($c_n_q_1_count==1){
							while($c_n_q_1_data=$c_n_q_1->fetch()){
								$read_yet_data=$c_n_q_1_data['read_yet'];
							}
							if($read_yet_data==0){
							}
							if($read_yet_data==1){
								$c_n_q_3=$dbconnect->prepare("UPDATE chat_notice SET read_yet=:read_yet WHERE notice_to='$to' AND notice_from='$from' ");
								$c_n_q_3->bindValue(':read_yet',0);
								$c_n_q_3->execute();
							}
						}//{n1}
						header("location: http://localhost/sn/php/chat/chat.php?id=$to");
						}else{
						echo "upload failed";
					}
				}
				if($extention=='zip'){
					if(move_uploaded_file($tmp_name,$location.$updated_name)){
						$msg_data_query=$dbconnect->prepare("INSERT INTO msg_data (msg_to,msg_from,data,f_node_name,b_node_name) VALUES (:to,:from,:data,:f_node_name,:b_node_name)");
						$msg_data_query->bindValue('to',$to);
						$msg_data_query->bindValue('from',$from);
						$msg_data_query->bindValue(':f_node_name',$f_node_name);
						$msg_data_query->bindValue(':b_node_name',$b_node_name);
						$msg_data_query->bindValue('data',$link_data);
						$msg_data_query->execute();
						//codeblocks for notification entry{n1}
						$c_n_q_1=$dbconnect->query("SELECT * FROM chat_notice WHERE notice_from='$from' AND notice_to='$to' ");
						$c_n_q_1_count=$c_n_q_1->rowCount();
						if($c_n_q_1_count==0){
							$c_n_q_2=$dbconnect->prepare("INSERT INTO chat_notice(notice_from,notice_to,data,read_yet) VALUES(:notice_from,:notice_to,:data,:read_yet) ");
							$c_n_q_2->bindValue(':notice_from',$from);
							$c_n_q_2->bindValue(':notice_to',$to);
							$c_n_q_2->bindValue(':data',$notice_data);
							$c_n_q_2->bindValue(':read_yet',0);
							$c_n_q_2->execute();
						}
						if($c_n_q_1_count==1){
							while($c_n_q_1_data=$c_n_q_1->fetch()){
								$read_yet_data=$c_n_q_1_data['read_yet'];
							}
							if($read_yet_data==0){
							}
							if($read_yet_data==1){
								$c_n_q_3=$dbconnect->prepare("UPDATE chat_notice SET read_yet=:read_yet WHERE notice_to='$to' AND notice_from='$from' ");
								$c_n_q_3->bindValue(':read_yet',0);
								$c_n_q_3->execute();
							}
						}//{n1}
						header("location: http://localhost/sn/php/chat/chat.php?id=$to");
						}else{
						echo "upload failed";
					}	
				}
				}else{
				die("not supported format");
			} 
		}
		if(empty($name)){
			if(!empty($msg_data_fltrd)){
				$msg_data_query=$dbconnect->prepare("INSERT INTO msg_data (msg_to,msg_from,data,f_node_name,b_node_name) VALUES (:to,:from,:data,:f_node_name,:b_node_name)");
				$msg_data_query->bindValue('to',$to);
				$msg_data_query->bindValue('from',$from);
				$msg_data_query->bindValue(':f_node_name',$f_node_name);
				$msg_data_query->bindValue(':b_node_name',$b_node_name);
				$msg_data_query->bindValue('data',$msg_data_fltrd);
				$msg_data_query->execute();
				//codeblocks for notification entry{n1}
				$c_n_q_1=$dbconnect->query("SELECT * FROM chat_notice WHERE notice_from='$from' AND notice_to='$to' ");
				$c_n_q_1_count=$c_n_q_1->rowCount();
				if($c_n_q_1_count==0){
					$c_n_q_2=$dbconnect->prepare("INSERT INTO chat_notice(notice_from,notice_to,data,read_yet) VALUES(:notice_from,:notice_to,:data,:read_yet) ");
					$c_n_q_2->bindValue(':notice_from',$from);
					$c_n_q_2->bindValue(':notice_to',$to);
					$c_n_q_2->bindValue(':data',$notice_data);
					$c_n_q_2->bindValue(':read_yet',0);
					$c_n_q_2->execute();
				}
				if($c_n_q_1_count==1){
					while($c_n_q_1_data=$c_n_q_1->fetch()){
						$read_yet_data=$c_n_q_1_data['read_yet'];
					}
					if($read_yet_data==0){
					}
					if($read_yet_data==1){
						$c_n_q_3=$dbconnect->prepare("UPDATE chat_notice SET read_yet=:read_yet WHERE notice_to='$to' AND notice_from='$from' ");
						$c_n_q_3->bindValue(':read_yet',0);
						$c_n_q_3->execute();
					}
				}//{n1}
				header("location: http://localhost/sn/php/chat/chat.php?id=$to");
				}else{
				//die("you cant let the message box empty");
			}
		}
	}
?>