<?php   
session_start();
require '../home/db_connect.php';
require '../home/query_user_session.php';
if(isset($_POST['back_node'])&&isset($u_primary_data)){
	$from=$u_primary_data;
	$to=$_POST['back_node'];
	$dom_update_query=$dbconnect->query("SELECT * FROM msg_data WHERE msg_to=('$to' or '$from') AND msg_from=('$from' or '$to') ORDER BY id DESC LIMIT 1");
	while($row=$dom_update_query->fetch()){
		$data=$row['data'];
		$msg_from=$row['msg_from'];
		$msg_to=$row['msg_to'];
		if($msg_from==$from){
			echo"<div class='p_content_wrapper'><p id='front_node'>$data</p></div>";
		}elseif($msg_from==$to){
			echo"<div class='p_content_wrapper'><p id='back_node'>$data.$msg_from.$msg_to</p></div>";
		}
	}
}
?>