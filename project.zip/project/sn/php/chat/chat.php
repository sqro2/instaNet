<?php
	session_start();
	require '../home/query_user_session.php';
	require '../username.php';
	require '../home/profile_image_retrived.php';
	if(isset($_GET['id'])){
		$back_node=$_GET['id'];
		$back_node_img_retrive_type_avater_query_1=$dbconnect->query("SELECT * FROM users WHERE id='$back_node'");
		while($retrive_session_info_back_node=$back_node_img_retrive_type_avater_query_1->fetch()){
			$back_node_session_info=$retrive_session_info_back_node['session_info'];
		}
		$back_node_img_retrive_type_avater_query_2=$dbconnect->query("SELECT img_url FROM user_profile_img WHERE uploader='$back_node_session_info'");
		while($retrive_img_url_back_node=$back_node_img_retrive_type_avater_query_2->fetch()){
			$retrived_img_url_back_node=$retrive_img_url_back_node['img_url'];
		}
		if($user_primary_id_retrived==$back_node){
			die("We don't allow sending messages to yourself.Sorry about that");
			}else{
			require '../home/db_connect.php';
			$back_node_validity_1=$dbconnect->query("SELECT * FROM users WHERE id='$back_node' ");
			$back_node_validity_2=$dbconnect->query("SELECT * FROM users WHERE id='$back_node' ");
			while($back_node_data_retrive=$back_node_validity_2->fetch()){
				$back_node_user_name=$back_node_data_retrive['username'];
			}
			$rows=$back_node_validity_1->rowCount();
			if($rows==0){
				die("no such user exists");
			}      
		}
		}else{
		die("Error with redirection");
	}
    require 'data_submit_handler.php';
?>
<!DOCTYPE html>
<html lang='en'>
	<head>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<meta charset='utf-8'>
<title>chat</title>
<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/chat/messages.css'/>
<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
<script type='text/javascript' src='http://localhost/sn/js/home/n_f_reminder.js'></script>
<script type='text/javascript' src='http://localhost/sn/js/chat/chat_jquery.js'></script>
<script type='text/javascript' src='http://localhost/sn/js/nf_script_jquery.js'></script>
<script type='text/javascript' src='http://localhost/sn/js/chat/plug_in_components_1.js'></script>
<script type='text/javascript' src='http://localhost/sn/js/chat/chat_plug_in_helper.js'></script>
<!--<script type='text/javascript' src='http://localhost/sn/js/chat/chatbox_dom_update.js'></script>-->
<script type='text/javascript' src='http://localhost/sn/js/chat/chatbox_ajax_dom_handler.js'></script>
</head>
<body>
	<div class='header' id='header'>
		<div class='header_content_wrapper'>
			<div class='header_content_wrapper_inner'>
				<ul class='header_items'>
				  <div class='header_user_data_inline_block_0'>
					<li class='nav_li_log_out'>
						<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-power-off' style='color:#779FC3;font-size:1.1em;line-height:45px'></i><span class='a_span'>Exit</span></a></strong> 
					</li>
					<li class='nav_bar'>
						<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-list' style='color:#779FC3;font-size:1.1em;line-height:45px'></i><span class='a_span'>Navigation</span></a></strong>
					</li>
					<li>
              <strong><a href='http://localhost/sn/notifications.php' id='hyperlink_notification'><i class='fa pull-left  fa-bell' style='color:#779FC3;font-size:1.1em;line-height:45px' id='n_f_icon'></i><span class='a_span'>Alerts</span></a></strong>
					</li>
				</div>
				</ul>
				<ul class='header_user_data'>
				  <div class='header_user_data_inline_block_1'>
					<li class='image_data'>
						<a href='http://localhost/sn/php/home/uploadphoto.php'><div class='user_retrived_img_container' style='background-image:url(<?php echo $avater_path ?>)'>
						</div></a>
					</li>
					<li class='text_data'>
						<strong>
							<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
								<i class='fa pull-left  fa-user' style='color:#1B5E1D;font-size:2em;line-height:60px' id='avater_head'></i>
								<?php  
									echo $user_name_retrived;
								?>
							</a>
						</strong>
					</li>
				  </div>
				</ul>
			</div>
		</div>
	</div>
	<div class='page_content_wrapper_outer'>
		<div class='page_content_wrapper_inner'>
		<div class='chat_box_wrapper_trans'>
			<div class='chat_box_wrapper'>
				
				<div class='chat_box_header_container'>
					<div class='chat_box_header_inner'>
						<ul>
							<li class='front-node'><h4 style='height:inherit;line-height:30px' class='remote_user_id'><?php echo $back_node_user_name?></h4></li>
							<li class='f_reciever'><span id='window_close'></span><span style='border:0px solid #0E3B37' id='up_file'><span id='span_up_file_0'><i class='fa fa-upload' id='span_up_file' style='font-size:inherit;line-height:inherit;margin-left:3px;float:left'></i></span><span id='span_up_file_1'>&#160Upload </span> </span></li>
						</ul>
					</div>
				</div>
				<form action='chat.php?id=<?php echo$back_node?>' method='post' enctype='multipart/form-data' id='ch_form_data'>
					<div class='upload_space_wrapper' id='upload_space_wrapper'>
						<div class='preview_space'>
							<input type='file' name='file' id='img_data_c_b'/>
							<input type='hidden' value=<?php echo $user_primary_id_retrived?> id='cl_1'/>
							<input type='hidden' value=<?php echo $back_node?> id='cl_2'/>
							
						</div>
					</div>
					<div class='chat_box_data_container' id='chat_box_data_container'>
						<div class='chat_box_data_container_inner'>
							<?php 
								require 'chatbox_dom_ready_handler_non_ajax.php';
							?>
						</div>
					</div>
					<div class='chat_box_footer_container' id='chat_box_footer_container'>
						<div class='chat_box_footer_container_inner'>
							<ul class='input_group'>
								<textarea class='front_node_data_type_text_img' id='front_node_data_type_text_img' name='msg_data' placeholder='write your message..'></textarea>
								<input type='text' name='msg_data_svp' id='front_node_data_type_text_img_svp' class='front_node_data_type_text_img_svp' placeholder='....' autofocus/>
								<div class='input_type_submit_wrapper'><input type='submit' class='push_data_o' value='send' name='submit'></input></div>
								<!--<div class='button_type_reply' id='button_type_reply'></div>-->
								
							</ul>
							
						</div>
					</div>
				</form>
				
			</div>
		</div>
		</div>
	 <div class='notification_wrapper' id='notification_wrapper' style='display:none' >
	    <div class='notification_content' style='display:table-row'>
		    <h3 style='padding:5px;text-align:center;border-bottom:1px solid #ccc;font-size:12px;line-height:20px;color:#0E3B37'>Notice Board</h3>
		    		<ul style='padding:8px;margin:0px;width:98%' id='notification_content_ul'>
							<?php
							    //require '../notification_script.php';
							 ?>
					
				    </ul>	
		</div>
	 </div>
	</div>
</body>
</html>
