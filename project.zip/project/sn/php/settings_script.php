<?php 
	require './php/db_connect.php';
	$session_id=$u_primary_data;
	if(isset($_POST['update_value_name'])&& isset($_POST['update_value_name_post'])){
		
		$user_name=$_POST['update_value_name'];
		$sub_data=$_POST['update_value_name_post'];
		$user_data_varification_query=$dbconnect->query("SELECT username FROM users WHERE username='$user_name'");
		if($user_data_varification_query->rowCount()>=1){
			die("Sorry The Username Already Taken.Try a Different One");
			}else{
			$user_data_update_query_name_1=$dbconnect->prepare("UPDATE users set username = :username WHERE session_info='$session_id'");
			$user_data_update_query_name_2=$dbconnect->prepare("UPDATE msg_data set f_node_name = :f_node_name WHERE msg_from='$user_primary_id_retrived'");
			$user_data_update_query_name_3=$dbconnect->prepare("UPDATE msg_data set b_node_name = :b_node_name WHERE msg_to='$user_primary_id_retrived'");
			$user_data_update_query_name_1->bindValue(':username',$user_name);
			$user_data_update_query_name_1->execute();
			$user_data_update_query_name_2->bindValue(':f_node_name',$user_name);
			$user_data_update_query_name_2->execute();
			$user_data_update_query_name_3->bindValue(':b_node_name',$user_name);
			$user_data_update_query_name_3->execute();
			die("<strong>Username Changed Successfuly <a href='http://localhost/sn/settings.php'>back</a></strong> ");
		}
		
		}else{
		
	}
	if(isset($_POST['update_value_location'])&& isset($_POST['update_value_location_post'])){
		$raw_location_data=$_POST['update_value_location'];
		$raw_location_data_insert_query=$dbconnect->prepare("UPDATE users set location=:location WHERE session_info='$session_id'");
		$raw_location_data_insert_query->bindValue(':location',$raw_location_data);
		$raw_location_data_insert_query->execute();
		die("<strong>Location Changed Successfuly <a href='http://localhost/sn/settings.php'>back</a></strong> ");
		
		
		}else{
		
		}
	if(isset($_POST['setting_gender_update'])&& isset($_POST['update_value_gender_post'])){
		$raw_gender_data=$_POST['setting_gender_update'];
		if(strtolower($raw_gender_data)=='male'||strtolower($raw_gender_data)=='female'){
		$raw_gender_data_insert_query=$dbconnect->prepare("UPDATE users set sex=:gender WHERE session_info='$session_id'");
		$raw_gender_data_insert_query->bindValue(':gender',$raw_gender_data);
		$raw_gender_data_insert_query->execute();
		die("<strong>Gender Changed Successfuly <a href='http://localhost/sn/settings.php'>back</a></strong> ");			
			
		}else{
		die("<strong>Could not proceed with your request.Please try again <a href='http://localhost/sn/settings.php'>back</a></strong></strong>");
		}

		
		
		}else{
		
		}
	
?>
