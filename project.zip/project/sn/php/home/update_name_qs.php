<?php
	session_start();
	require 'db_connect.php';
	require 'query_user_session.php';
	require '../username.php';
	if(isset($_POST['updated_name'])){//1
		$choosed_user_name=$_POST['updated_name'];
		if(!empty($choosed_user_name)){//2
			$session_id=$u_primary_data;
			$user_data_varification_query=$dbconnect->query("SELECT username FROM users WHERE username='$choosed_user_name'");
			if($user_data_varification_query->rowCount()==1 || $user_data_varification_query->rowCount()>1){//3
				die("Sorry The Username Already Taken.Try a Different One");
				}else{
				$user_data_update_query_1=$dbconnect->prepare("UPDATE users set username = :username WHERE session_info='$session_id'");
				$user_data_update_query_2=$dbconnect->prepare("UPDATE msg_data set f_node_name = :f_node_name WHERE msg_from='$user_primary_id_retrived'");
				$user_data_update_query_3=$dbconnect->prepare("UPDATE msg_data set b_node_name = :b_node_name WHERE msg_to='$user_primary_id_retrived'");
				$user_data_update_query_1->bindValue(':username',$choosed_user_name);
				$user_data_update_query_1->execute();
				$user_data_update_query_2->bindValue(':f_node_name',$choosed_user_name);
				$user_data_update_query_2->execute();
				$user_data_update_query_3->bindValue(':b_node_name',$choosed_user_name);
				$user_data_update_query_3->execute();
				echo "Username Changed Successfuly. You might need to refresh the page for the change to take effect";
			}//3
			
			}else{
			die("You must choose an username");
		}//2
		}
		else{
			die("Cauld not recieve data");
			
		}//1
		
	?>	