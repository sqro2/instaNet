<?php
   $location_retrive_query_1=$dbconnect->query("SELECT location FROM users WHERE session_info='$u_primary_data' ");
   while($location_data=$location_retrive_query_1->fetch()){
	  $retrived_location=$location_data['location'];
	   }
   
?>	