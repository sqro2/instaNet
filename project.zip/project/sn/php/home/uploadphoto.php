<?php
	session_start();
	require '../home/query_user_session.php';
	require '../username.php';
    require 'profile_image_retrived.php';
	if(isset($_POST['button_type_submit'])){
		$raw_img_name=$_FILES['button_type_browse']['name'];
		$suffled_img_name_string=strtolower(str_shuffle($raw_img_name));
		$suffled_img_name_string_null_white_space = str_replace(' ','',$suffled_img_name_string);
		$user_name_retrived_null_whitespace = str_replace(' ','',$user_name_retrived);
		$raw_img_size=$_FILES['button_type_browse']['size'];
		$raw_img_type=$_FILES['button_type_browse']['type'];
		$tmp_name_type_file=$_FILES['button_type_browse']['tmp_name'];
		$raw_img_extention=pathinfo($raw_img_name, PATHINFO_EXTENSION);//strtolower(substr($raw_img_name, strpos($raw_img_name, '.')+1));
		$updated_img_name=$suffled_img_name_string_null_white_space.'_'.$user_name_retrived_null_whitespace.'.'.$raw_img_extention;
		$raw_img_location=$_SERVER['DOCUMENT_ROOT'].'/sn/assets/uploads/user_profiles/avaters/';
		$updated_img_location=str_replace('C:/xampp/htdocs','http://localhost',$raw_img_location);
		$updated_img_url=$updated_img_location.$updated_img_name;


	  if(!empty($raw_img_name)){//3
	   if($raw_img_extention=='jpg' || $raw_img_extention=='jpeg' || $raw_img_extention=='png'){//4
		    if(move_uploaded_file($tmp_name_type_file,$raw_img_location.$updated_img_name)){//5
				  $profile_pic_update_query=$dbconnect->prepare("UPDATE user_profile_img set img_url=:path WHERE uploader='$u_primary_data' ");
				  $users_table_update_query=$dbconnect->prepare("UPDATE users set url_avater=:url_avater WHERE session_info='$u_primary_data' ");
				  $profile_pic_update_query->bindValue(':path',$updated_img_url);
				  $profile_pic_update_query->execute();
				  $users_table_update_query->bindValue('url_avater',$updated_img_url);
				  $users_table_update_query->execute();
				  header("location: http://localhost/sn/php/home/home.php");
				  
				}//5
				else{
					die("Something Went Wrong.we are sorry about that <strong><a href='http://localhost/sn/php/home/uploadphoto.php'>back</a></strong>");
					}
		    
		   }//4 
		else{
			die("the file must be an image file with maximum limit 2mb <strong><a href='http://localhost/sn/php/home/uploadphoto.php'>back</a></strong>");
			}
	   
	   }//3
		
	}
	//else{
		//echo "not set";
		//}

?>
<!DOCTYPE html>
<html lang='en'>
	<head>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<meta charset='utf-8'>
<title>Upload Image</title>
<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/home/ui_stylesheet.css'/>
<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
</head>
<body>
	<div class='header'>
		<div class='header_content_wrapper'>
			<div class='header_content_wrapper_inner'>
				<ul class='header_items'>
					<li class='nav_li_log_out'>
						<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-hourglass-end' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>logout</span></a></strong> 
					</li>
					<li class='nav_bar'>
						<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-bars' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>nav_menu</span></a></strong>
					</li>
					<li>
						<strong><a href='http://localhost/sn/notifications.php'><i class='fa pull-left  fa-bell' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>notification</span></a></strong>
					</li>
				</ul>
				<ul class='header_user_data'>
					<li class='image_data'>
						<div class='user_retrived_img_container' style='background-image:url(<?php echo $avater_path ?>)'>
						</div>
					</li>
					<li class='text_data'>
						<strong>
							<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
								<i class='fa pull-left  fa-user' style='color:#1B5E1D;font-size:2em;line-height:60px' id='avater_head'></i>
								<?php  
									echo $user_name_retrived;
								?>
							</a>
						</strong>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class='page_content_wrapper_outer'>
		<div class='page_content_wrapper_inner'>
           <div class='up_data_form_1'>
		    <div class='form_wrapper'>
			   <form action='uploadphoto.php' method='post' enctype='multipart/form-data'>
			    <input type='file' id='button_type_browse' name='button_type_browse' class='button_type_browse'/>
				<input type='submit' name='button_type_submit' id='button_type_submit' class='button_type_submit' value='Upload'/>
			   </form>
			</div>
		   </div>
		</div>
	</div>
</body>
</html>
