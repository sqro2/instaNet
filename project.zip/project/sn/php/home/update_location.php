<?php
	session_start();
	require 'db_connect.php';
	require 'query_user_session.php';
	if(isset($_POST['raw_location_data'])){
		$new_location=$_POST['raw_location_data'];
		if(!empty($new_location)){
			$new_location_inject_query=$dbconnect->prepare("UPDATE users set location=:location WHERE session_info='$u_primary_data'");
			$new_location_inject_query->bindValue(':location',$new_location);
			$new_location_inject_query->execute();
			echo "Your location updated Successfuly. You might need to refresh the page for the change to take effect";
			}else{
			die("input field must not empty");
		}
		
	}	
?>