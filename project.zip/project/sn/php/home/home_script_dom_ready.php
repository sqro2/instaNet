<?php  
	if(!empty($interest_front_node)){
	$interest_front_node_metaphone=metaphone($interest_front_node);
	$interest_front_node_metaphone_2=metaphone($interest_front_node_metaphone);
	$dom_populate_query_2=$dbconnect->query("SELECT * FROM users WHERE metaphone='$interest_front_node_metaphone_2' AND avail='true' ORDER BY id ASC LIMIT $pagination_limit_initial,$pagination_result_limit_final");
	while($front_end_data_set_2=$dom_populate_query_2->fetch()){
							$user_name=$front_end_data_set_2['username'];
							$user_primary_id=$front_end_data_set_2['id'];
							$user_sex=$front_end_data_set_2['sex'];
							$user_country=$front_end_data_set_2['location'];
							$user_interest=$front_end_data_set_2['interest'];
							$user_tweet=$front_end_data_set_2['tweet'];
							$avater_path_retrived=$front_end_data_set_2['url_avater'];
							$user_gender_strtolower=strtolower($user_sex);
                          $user_info_view="<div class='cell_container_wrapper'><div class='cell_header'><div class='cell_icon_png'><img src='$avater_path_retrived' id='cell_icon_png_inner'></img></div><div class='sub_heading_1'><input type='hidden' id='u_data' value='$user_primary_id'/><strong><a href='../chat/chat.php?id=$user_primary_id' class='redirect' id='$user_primary_id'>$user_name</a></strong><span class='sub_heading_span_el_1'>wants to talk about</span><span class='sub_heading_span_el_2'> $user_interest</span></div></div><div class='article'><article>$user_tweet</article></div><div class='cell_ul_items'><ul><li><i class='fa pull-left  fa-$user_gender_strtolower' style='color:#9a9a9a;font-size:1.3em;line-height:30px'></i>$user_sex</li><li><i class='fa pull-left  fa-map-marker' style='color:#9a9a9a;font-size:1.3em;line-height:30px'></i>$user_country</li></ul></div></div>";
                            
		             echo $user_info_view; 

		
		
		}
					
	}
	else{
	
		
		}
		
		
		
		
/*	while($front_end_data_set_2=$dom_populate_query_2->fetch()){
							$user_name=$front_end_data_set_2['username'];
							$user_primary_id=$front_end_data_set_2['id'];
							$user_sex=$front_end_data_set_2['sex'];
							$user_country=$front_end_data_set_2['location'];
							$user_interest=$front_end_data_set_2['interest'];
							$user_tweet=$front_end_data_set_2['tweet'];
							$avater_path_retrived=$front_end_data_set_2['url_avater'];
							$user_gender_strtolower=strtolower($user_sex);
                          $user_info_view="<div class='cell_container_wrapper'><div class='cell_header'><div class='cell_icon_png'><img src='$avater_path_retrived' id='cell_icon_png_inner'></img></div><div class='sub_heading_1'><input type='hidden' id='u_data' value='$user_primary_id'/><strong><a href='../chat/chat.php?id=$user_primary_id' class='redirect' id='$user_primary_id'>$user_name</a></strong><span class='sub_heading_span_el_1'>wants to talk about</span><span class='sub_heading_span_el_2'> $user_interest</span></div></div><div class='article'><article>$user_tweet</article></div><div class='cell_ul_items'><ul><li><i class='fa pull-left  fa-$user_gender_strtolower' style='color:#9a9a9a;font-size:1.3em;line-height:30px'></i>$user_sex</li><li><i class='fa pull-left  fa-map-marker' style='color:#9a9a9a;font-size:1.3em;line-height:30px'></i>$user_country</li></ul></div></div>";
		             echo $user_info_view; 
		
		
		}
					
	}
		
		
	*/	
		
		
		
		
		
		
?>
