<?php
	
	if(isset($_POST['data'])){
		$data=$_POST['data'];
		echo $data;
		return $data;
		echo "$('#section_3').hide()";
		}
	
	
?>	