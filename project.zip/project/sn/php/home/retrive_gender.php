<?php
$retrive_gender_query_1=$dbconnect->query("SELECT sex FROM users WHERE session_info='$u_primary_data'");
while($gender_data=$retrive_gender_query_1->fetch()){
	$retrive_gender=$gender_data['sex'];
	}
?>