<?php  
	
	$trend_graph_dom_ready_query_1=$dbconnect->query("SELECT topic,act_node FROM trend_graph ORDER BY act_node DESC LIMIT 10");
	while($trend_graph_dom_ready_data=$trend_graph_dom_ready_query_1->fetch()){
		$retrived_topic=$trend_graph_dom_ready_data['topic'];
		$retrived_searches=$trend_graph_dom_ready_data['act_node'];
		$dom_view_topic="<div id='sec_2_trend_graph_wrapper'><a href='http://localhost/sn/php/home/home.php?p_n=1&i=$retrived_topic'>$retrived_topic</a><div id='search_stat_wrapper'>[$retrived_searches] users searching</div></div>";
		echo $dom_view_topic;
		}
	
	
	
?>