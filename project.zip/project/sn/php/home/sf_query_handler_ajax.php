<?php
	session_start();
	require'db_connect.php';
	require 'query_user_session.php';
	require '../username.php';
	require 'profile_image_retrived.php';
	require 'retrive_location.php';
	require 'retrive_gender.php';
	$u_sub_of_interest;
	if(isset($_POST['r_count_final'])){
	$retrive_data_previous_query=$dbconnect->query("SELECT interest from users Where session_info='$u_primary_data' ");
	while($data_set_1=$retrive_data_previous_query->fetch()){
				$u_sub_of_interest=$data_set_1['interest'];
		}
		$initial_count=$_POST['r_count_final'];
		$final_count=$initial_count+20;
		$u_sub_of_interest_fltrd=trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $u_sub_of_interest)));
		if(is_numeric($initial_count)){
			if(!empty($u_sub_of_interest_fltrd)){
				$app_data_extraction=$dbconnect->query("SELECT * FROM users WHERE interest='$u_sub_of_interest_fltrd' && avail='true' ORDER BY id ASC LIMIT $initial_count, 20  ");
				if($app_data_extraction->rowCount()>0){
					while($row=$app_data_extraction->fetch()){
						$user_name=$row['username'];
						$user_sex=$row['sex'];
						$user_country=$row['location'];
						$user_lang=$row['language'];
						$user_interest=$row['interest'];
						$user_tweet=$row['tweet'];
						$avater_path_retrived=$row['url_avater'];
						$user_gender_strtolower=strtolower($user_sex);
						$user_info_view="<div class='cell_container_wrapper'><div class='cell_header'><div class='cell_icon_png'><img src='$avater_path_retrived' id='cell_icon_png_inner'></img></div><div class='sub_heading_1'><strong><a href='../chat/chat.php?id=$user_name' class='redirect'>$user_name</a></strong><span class='sub_heading_span_el_1'>wants to talk about</span><span class='sub_heading_span_el_2'> $user_interest</span></div></div><div class='article'><article>$user_tweet</article></div><div class='cell_ul_items'><ul><li><i class='fa pull-left  fa-$user_gender_strtolower' style='color:#9a9a9a;font-size:1.3em;line-height:30px'></i>$user_sex</li><li><i class='fa pull-left  fa-map-marker' style='color:#9a9a9a;font-size:1.3em;line-height:30px'></i>$user_country</li></ul></div></div>";
						echo $user_info_view;  
						echo "<script type='text/javascript'>
						$('#query_id_final').val($final_count);
						if($(window).innerWidth()>799){
						$('.redirect').click(function(){
						$('.new_frame').show();
						$(this).attr('target','new_frame');
						});
						}
						</script>";
					}
					}else{
					echo "<script type='text/javascript'>
					$('#query_id_final').val($initial_count);
					$('.error_reoprt').show();
					$('.error_reoprt').html('<strong>No Result Found (:</strong>');
					</script>";
				}
				
				}else{
				die("input should not be empty");
			}
			}else{
			die("something went wrong"); 
		}
		
	}
?>