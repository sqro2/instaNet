<?php  
	if(isset($_POST['sf_input'])&&isset($_POST['sf_data'])){//[1]
		$u_primary_data=$_SESSION["user_data"];		
		$u_sub_of_interest=$_POST['sf_input'];
		$u_sub_of_interest_fltrd=trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $u_sub_of_interest)));
		$interest_metaphone=metaphone($u_sub_of_interest_fltrd);
		$interest_metaphone_2=metaphone($interest_metaphone);
		$raw_tweet=$_POST['message'];
		$u_tweet=htmlentities($raw_tweet);
		$final_num_row=5;
		//variables for processing image data
		$name=$_FILES['image_picker']['name'];
		$suffled_name_string=strtolower(str_shuffle($name));
		$rand_int=mt_rand(10000,100000000);
		$size=$_FILES['image_picker']['size'];
		$type=$_FILES['image_picker']['type'];
		$extention=pathinfo($name, PATHINFO_EXTENSION);//strtolower(substr($name, strpos($name, '.')+1));
		$updated_name=$suffled_name_string.$rand_int.'_'.$user_name_retrived.'_'.$rand_int.'.'.$extention;
		$tmp_name=$_FILES['image_picker']['tmp_name'];
		$location=$_SERVER['DOCUMENT_ROOT'].'/sn/assets/uploads/user_profiles/data/';
		$updated_location=str_replace('C:/xampp/htdocs','http://localhost',$location);
		$updated_url='/sn/assets/uploads/user_profiles/data/'.$updated_name;//$updated_location.$updated_name;
		$img_token=$u_primary_data.$name;
		$img_data="<img src='$updated_url' id='u_tweet_image'></img>";
		$link_data="<a href='$updated_url'>$name</a>";
		$u_pic_tweet="<p>$u_tweet</p><div class='article_wrapper'><p>$img_data</p></div>";
		$u_link_tweet="<p>$u_tweet</p><div class='article_wrapper'><p>$link_data</p></div>";
		
		if(empty($name)){//[2]
			if($u_sub_of_interest_fltrd!=""&&!ctype_space($u_sub_of_interest_fltrd)){//[3]
				//codeblocks to update trend_graph before change
				$t_g_search_q_0=$dbconnect->query("SELECT interest FROM users WHERE session_info='$u_primary_data' AND avail='true' ");
				while($t_g_search_q_0_data=$t_g_search_q_0->fetch()){
					$interest_pre=$t_g_search_q_0_data['interest'];
					
				}
				
				$app_data_injection=$dbconnect->prepare("UPDATE users set interest=:interest,avail=:avail,tweet=:tweet,metaphone=:m_phone WHERE username='$user_name_retrived' ");
				$app_data_injection->bindValue(':interest',$u_sub_of_interest_fltrd);
				$app_data_injection->bindValue(':avail',"true");
				$app_data_injection->bindValue(':tweet',$u_tweet);
				$app_data_injection->bindValue(':m_phone',$interest_metaphone_2);
				$app_data_injection->execute();
				//codeblocks to update trend_graph after change
				$t_g_search_q_1=$dbconnect->query("SELECT username FROM users WHERE interest='$u_sub_of_interest_fltrd' ");
				$c_0=$t_g_search_q_1->rowCount();
				$t_g_search_q_2=$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$u_sub_of_interest_fltrd' ");
				$t_g_search_q_2_a=$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$interest_pre' ");
				if($t_g_search_q_2_a->rowCount()==0){
					
					}else{
					while($t_g_search_q_2_a_data=$t_g_search_q_2_a->fetch()){
						$retrived_act_node_pre=$t_g_search_q_2_a_data['act_node'];
						$updated_act_node_pre=$retrived_act_node_pre-1;
						$t_g_search_q_5=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$interest_pre' ");
						$t_g_search_q_5->bindValue(':act_node',$updated_act_node_pre);
						$t_g_search_q_5->execute();
					}
				}
				$c_1=$t_g_search_q_2->rowCount();
				while($t_g_search_q_2_data=$t_g_search_q_2->fetch()){
					$retrived_act_node=$t_g_search_q_2_data['act_node'];
					$updated_act_node=$retrived_act_node+1;
				}
				if($c_1==1){
					$t_g_search_q_3=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$u_sub_of_interest_fltrd' ");
					$t_g_search_q_3->bindValue(':act_node',$updated_act_node);
					$t_g_search_q_3->execute();
				}
				if($c_1==0){
					$t_g_search_q_4=$dbconnect->prepare("INSERT INTO trend_graph(topic,act_node) VALUES(:topic,:act_node)");
					$t_g_search_q_4->bindValue(':topic',$u_sub_of_interest_fltrd);
					$t_g_search_q_4->bindValue(':act_node',$c_0);
					$t_g_search_q_4->execute();
				}
				
				header("location: http://localhost/sn/php/home/home.php?p_n=1");
				
			}//[3]
			else{
				header("location: http://localhost/sn/php/home/home.php?p_n=1");
			}
			
		}//[2]	
		
		if(!empty($name)&&!empty($tmp_name)){//[a]
			if($size<=10485760){//m
				//codeblocks to update trend_graph before change
				$t_g_search_q_0=$dbconnect->query("SELECT interest FROM users WHERE session_info='$u_primary_data' ");
				while($t_g_search_q_0_data=$t_g_search_q_0->fetch()){
					$interest_pre=$t_g_search_q_0_data['interest'];
					
				}
				
				if($extention=='jpg'||$extention=='jpeg'||$extention=='png'||$extention=='zip'){//[c]
					if($extention=='jpg'||$extention=='jpeg'||$extention=='png'){//p
						
						if(move_uploaded_file($tmp_name,$location.$updated_name)){//[d]
							
							if($u_sub_of_interest_fltrd!=""&&!ctype_space($u_sub_of_interest_fltrd)){//[e]
								$app_data_injection=$dbconnect->prepare("UPDATE users set interest=:interest,avail=:avail,tweet=:tweet,metaphone=:m_phone WHERE username='$user_name_retrived' ");
								$app_data_injection->bindValue(':interest',$u_sub_of_interest_fltrd);
								$app_data_injection->bindValue(':avail',"true");
								$app_data_injection->bindValue(':tweet',$u_pic_tweet);
								$app_data_injection->bindValue(':m_phone',$interest_metaphone_2);
								$app_data_injection->execute();
								//codeblocks to update trend_graph after change
								$t_g_search_q_1=$dbconnect->query("SELECT username FROM users WHERE interest='$u_sub_of_interest_fltrd' ");
								$c_0=$t_g_search_q_1->rowCount();
								$t_g_search_q_2=$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$u_sub_of_interest_fltrd' ");
								$t_g_search_q_2_a=$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$interest_pre' ");
								if($t_g_search_q_2_a->rowCount()==0){
									
									}else{
									while($t_g_search_q_2_a_data=$t_g_search_q_2_a->fetch()){
										$retrived_act_node_pre=$t_g_search_q_2_a_data['act_node'];
										$updated_act_node_pre=$retrived_act_node_pre-1;
										$t_g_search_q_5=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$interest_pre' ");
										$t_g_search_q_5->bindValue(':act_node',$updated_act_node_pre);
										$t_g_search_q_5->execute();
									}
								}
								$c_1=$t_g_search_q_2->rowCount();
								while($t_g_search_q_2_data=$t_g_search_q_2->fetch()){
									$retrived_act_node=$t_g_search_q_2_data['act_node'];
									$updated_act_node=$retrived_act_node+1;
								}
								if($c_1==1){
									$t_g_search_q_3=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$u_sub_of_interest_fltrd' ");
									$t_g_search_q_3->bindValue(':act_node',$updated_act_node);
									$t_g_search_q_3->execute();
								}
								if($c_1==0){
									$t_g_search_q_4=$dbconnect->prepare("INSERT INTO trend_graph(topic,act_node) VALUES(:topic,:act_node)");
									$t_g_search_q_4->bindValue(':topic',$u_sub_of_interest_fltrd);
									$t_g_search_q_4->bindValue(':act_node',$c_0);
									$t_g_search_q_4->execute();
								}
								header("location: http://localhost/sn/php/home/home.php?p_n=1");
								
							}//[e]
							
							else{
								header("location: http://localhost/sn/php/home/home.php?p_n=1");
							}
						}//[d]
						
						else{
							echo"image caulded not be uploaded";
						}
						
						
					}//p
					if($extention=='zip'){//q
						if(move_uploaded_file($tmp_name,$location.$updated_name)){//[d]
							
							if($u_sub_of_interest_fltrd!=""&&!ctype_space($u_sub_of_interest_fltrd)){//[e]
								$app_data_injection=$dbconnect->prepare("UPDATE users set interest=:interest,avail=:avail,tweet=:tweet,metaphone=:m_phone WHERE username='$user_name_retrived' ");
								$app_data_injection->bindValue(':interest',$u_sub_of_interest_fltrd);
								$app_data_injection->bindValue(':avail',"true");
								$app_data_injection->bindValue(':tweet',$u_link_tweet);
								$app_data_injection->bindValue(':m_phone',$interest_metaphone_2);
								$app_data_injection->execute();
								//codeblocks to update trend_graph after change
								$t_g_search_q_1=$dbconnect->query("SELECT username FROM users WHERE interest='$u_sub_of_interest_fltrd' ");
								$c_0=$t_g_search_q_1->rowCount();
								$t_g_search_q_2=$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$u_sub_of_interest_fltrd' ");
								$t_g_search_q_2_a=$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$interest_pre' ");
								if($t_g_search_q_2_a->rowCount()==0){
									
									}else{
									while($t_g_search_q_2_a_data=$t_g_search_q_2_a->fetch()){
										$retrived_act_node_pre=$t_g_search_q_2_a_data['act_node'];
										$updated_act_node_pre=$retrived_act_node_pre-1;
										$t_g_search_q_5=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$interest_pre' ");
										$t_g_search_q_5->bindValue(':act_node',$updated_act_node_pre);
										$t_g_search_q_5->execute();
									}
								}
								$c_1=$t_g_search_q_2->rowCount();
								while($t_g_search_q_2_data=$t_g_search_q_2->fetch()){
									$retrived_act_node=$t_g_search_q_2_data['act_node'];
									$updated_act_node=$retrived_act_node+1;
								}
								if($c_1==1){
									$t_g_search_q_3=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$u_sub_of_interest_fltrd' ");
									$t_g_search_q_3->bindValue(':act_node',$updated_act_node);
									$t_g_search_q_3->execute();
								}
								if($c_1==0){
									$t_g_search_q_4=$dbconnect->prepare("INSERT INTO trend_graph(topic,act_node) VALUES(:topic,:act_node)");
									$t_g_search_q_4->bindValue(':topic',$u_sub_of_interest_fltrd);
									$t_g_search_q_4->bindValue(':act_node',$c_0);
									$t_g_search_q_4->execute();
								}
								header("location: http://localhost/sn/php/home/home.php?p_n=1");
								
							}//[e]
							
							else{
								header("location: http://localhost/sn/php/home/home.php?p_n=1");
							}
						}//[d]
						
						else{
							echo"file caulded not be uploaded";
						}
						
					}//q
					//end of the block that do things when images gets uploaded sucessfully
					
				}//[c]
				else{
					die("the file must be an image file or a compressed zip file with maximum limit 10mb <strong><a href='http://localhost/sn/php/home/home.php'>back</a></strong>");
				}
			}//m
			else{
				die("upload limit exceeded <strong><a href='http://localhost/sn/php/home/home.php'>back</a></strong>");
			}
			
		}//[a]
		
		
	}//[1]
	
?>
