<?php 
if(isset($_POST['user_profile_img_post'])){
		$tmp_img_name=$_FILES['img_avatar']['name'];
		$suffled_img_name_string=strtolower(str_shuffle($tmp_img_name));
		$suffled_img_name_string_null_white_space = str_replace(' ','',$suffled_img_name_string);
		$user_name_retrived_null_whitespace = str_replace(' ','',$user_name_retrived);
		$img_size=$_FILES['img_avatar']['size'];
		$img_type=$_FILES['img_avatar']['type'];
		$tmp_name_type_file=$_FILES['img_avatar']['tmp_name'];
		$img_extention=$extention=pathinfo($tmp_img_name, PATHINFO_EXTENSION);//strtolower(substr($tmp_img_name, strpos($tmp_img_name, '.')+1));
		$updated_img_name=$suffled_img_name_string_null_white_space.'_'.$user_name_retrived_null_whitespace.'.'.$img_extention;
		$img_location=$_SERVER['DOCUMENT_ROOT'].'/sn/assets/uploads/user_profiles/avaters/';
		$updated_img_location=str_replace('C:/xampp/htdocs','http://localhost',$img_location);
		$updated_img_url=$updated_img_location.$updated_img_name; 

	  if(!empty($tmp_img_name)){//3
	   if($img_extention=='jpg' || $img_extention=='jpeg' || $img_extention=='png'){//4
		    if(move_uploaded_file($tmp_name_type_file,$img_location.$updated_img_name)){//5
				  $profile_pic_update_query=$dbconnect->prepare("UPDATE user_profile_img set img_url=:path WHERE uploader='$u_primary_data' ");
				  $users_table_update_query=$dbconnect->prepare("UPDATE users set url_avater=:url_avater WHERE session_info='$u_primary_data' ");
				  $profile_pic_update_query->bindValue(':path',$updated_img_url);
				  $profile_pic_update_query->execute();
				  $users_table_update_query->bindValue('url_avater',$updated_img_url);
				  $users_table_update_query->execute();
				  header("location: http://localhost/sn/php/home/home.php");
				  
				}//5
				else{
					die("Something Went Wrong.we are sorry about that <strong><a href='http://localhost/sn/php/home/home.php'>back</a></strong>");
					}
		    
		   }//4 
		else{
			die("the file must be an image file with maximum limit 2mb <strong><a href='http://localhost/sn/php/home/home.php'>back</a></strong>");
			}
	   
	   }//3
	
	}//1
    else{

	}	
	
?>