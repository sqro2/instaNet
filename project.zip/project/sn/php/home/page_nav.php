<?php
	if(isset($_GET['p_n'])){//1
		$current_page=$_GET['p_n'];
		if(isset($_GET['i'])){
			$interest_front_node=$_GET['i'];
			if(preg_match('/^\d+$/D',$current_page) && ($current_page>0)){//2
				if(!empty($interest_front_node)){//3
					$pagination_query_0=$dbconnect->query("SELECT * FROM users WHERE interest='$interest_front_node' AND avail='true'");
					$pagination_query_num_result=$pagination_query_0->rowCount();
					$pagination_result_limit_final=2;
					$pagination_num_page_total=ceil($pagination_query_num_result/$pagination_result_limit_final);
					$pagination_limit_initial=($current_page-1)*$pagination_result_limit_final;
					if($current_page>$pagination_num_page_total){
						header ('location: http://localhost/sn/php/home/home.php?p_n=1');
					}
					}else{
					
				}//3
				}else{
				header ('location: http://localhost/sn/php/home/home.php?p_n=1');
			}//2
			}else{
			if(preg_match('/^\d+$/D',$current_page) && ($current_page>0)){//2
				$interest_front_node;
				$dom_populate_query_1=$dbconnect->query("SELECT interest FROM users WHERE session_info='$u_primary_data'");
				while($front_end_data_set_1=$dom_populate_query_1->fetch()){
					$interest_front_node=$front_end_data_set_1['interest'];
				}
				if(!empty($interest_front_node)){//3
					$pagination_query_1=$dbconnect->query("SELECT * FROM users WHERE interest='$interest_front_node' AND avail='true'");
					$pagination_query_num_result=$pagination_query_1->rowCount();
					$pagination_result_limit_final=2;
					$pagination_num_page_total=ceil($pagination_query_num_result/$pagination_result_limit_final);
					$pagination_limit_initial=($current_page-1)*$pagination_result_limit_final;
					if($current_page>$pagination_num_page_total){
						header ('location: http://localhost/sn/php/home/home.php?p_n=1');
					}
					}else{
					
				}//3
				}else{
				header ('location: http://localhost/sn/php/home/home.php?p_n=1');
			}//2
		}
		}else{
		header ('location: http://localhost/sn/php/home/home.php?p_n=1');
	}//1
?>