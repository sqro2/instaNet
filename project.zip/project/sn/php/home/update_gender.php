<?php
	session_start();
	require 'db_connect.php';
	require 'query_user_session.php';	
	
	if(isset($_POST['raw_gender_data'])){
		$raw_gender_data=$_POST['raw_gender_data'];
		if(!empty($raw_gender_data)){
			if(strtolower($raw_gender_data)=="male" ||strtolower($raw_gender_data)=="female"){
				$updated_gender_insert_query=$dbconnect->prepare("UPDATE users set sex=:gender WHERE session_info='$u_primary_data'");
				$updated_gender_insert_query->bindValue(':gender',$raw_gender_data);
				$updated_gender_insert_query->execute();
				echo "Your data updated successfuly.You might need to refress the page for the changes to take effect";
				}else{
				die("sorry we can't process your request");
			}
			}else{
			die("no input recieved");
		}
		
		
	}	
?>