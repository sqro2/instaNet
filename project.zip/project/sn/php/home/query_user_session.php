<?php  
   if(isset($_SESSION["user_data"])){
	$u_primary_data=$_SESSION["user_data"];
	   }else{
		   header ('location: http://localhost/sn/user_log_in.php');
	   }
?>