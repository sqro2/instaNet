          <?php 
		    $x;
		    for($x=1;$x<5;$x++){
				echo "<a href=$x>$x</a>";
				}
		  ?>