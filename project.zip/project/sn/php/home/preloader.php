<?php
    $interest_front_node_string;
   $preloader_validation_query_1=$dbconnect->query("SELECT * FROM users WHERE username='$user_name_retrived'");
   while($retrived_string_interest=$preloader_validation_query_1->fetch()){
	  $interest_front_node_string=$retrived_string_interest['interest'];
	   }
	if(!empty($interest_front_node_string))	{
		echo "<script type='text/javascript'>$('#load').show();</script>";
		}
	else{
		echo "<script type='text/javascript'>$('#load').hide();</script>";
		}
	
	
?>