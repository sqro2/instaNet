<?php
   $profile_image_retrive_query_1=$dbconnect->query("SELECT * FROM user_profile_img WHERE uploader='$u_primary_data'");
   $avater_path;
   while($avater_data=$profile_image_retrive_query_1->fetch()){
	    $avater_path=$avater_data['img_url'];
	   }
	   ?>	
	
	