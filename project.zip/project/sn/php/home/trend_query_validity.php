<?php
	session_start();
	require'query_user_session.php';
	header('Content-Type: text/html; charset=utf-8');
	require'db_connect.php';
	$t_g_search_q_0=$dbconnect->query("SELECT interest FROM users WHERE session_info='$u_primary_data' ");
	while($t_g_search_q_0_data=$t_g_search_q_0->fetch()){
		$interest_pre=$t_g_search_q_0_data['interest'];
		$u_sub_of_interest_fltrd="facebook";
	}
	
	
	
	
	
	
	$t_g_search_q_1=$dbconnect->query("SELECT * FROM users WHERE interest='$u_sub_of_interest_fltrd' ");
	$c_0=$t_g_search_q_1->rowCount();
	$t_g_search_q_2=$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$u_sub_of_interest_fltrd' ");
	echo $t_g_search_q_2->rowCount();
	$t_g_search_q_2_a->$dbconnect->query("SELECT * FROM trend_graph WHERE topic='$interest_pre' ");
	if($t_g_search_q_2_a->rowCount()==0){
		
		}else{
		while($t_g_search_q_2_a_data=$t_g_search_q_2_a->fetch()){
			$retrived_act_node_pre=$t_g_search_q_2_a_data['act_node'];
			$updated_act_node_pre=$retrived_act_node_pre-1;
			$t_g_search_q_5=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$interest_pre' ");
			$t_g_search_q_5->bindValue(':act_node',$updated_act_node_pre);
			$t_g_search_q_5->execute();
		}
	}
	$c_1=$t_g_search_q_2->rowCount();
	while($t_g_search_q_2_data=$t_g_search_q_2->fetch()){
		$retrived_act_node=$t_g_search_q_2_data['act_node'];
		$updated_act_node=$retrived_act_node+1;
	}
	if($c_1==1){
		$t_g_search_q_3=$dbconnect->prepare("UPDATE trend_graph set act_node=:act_node WHERE topic='$u_sub_of_interest_fltrd' ");
		$t_g_search_q_3->bindValue(':act_node',$updated_act_node);
		$t_g_search_q_3->execute();
	}
	if($c_1==0){
		$t_g_search_q_4=$dbconnect->prepare("INSERT INTO trend_graph(topic,act_node) VALUES(:topic,:act_node)");
		$t_g_search_q_4->bindValue(':topic',$u_sub_of_interest_fltrd);
		$t_g_search_q_4->bindValue(':act_node',$c_0);
		$t_g_search_q_4->execute();
	}
	
?>