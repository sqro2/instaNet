<?php 
  session_start();
  require'query_user_session.php';
  header('Content-Type: text/html; charset=utf-8');
  require'db_connect.php';
  require 'page_nav.php';
  require '../username.php';
  require 'profile_image_upload.php';
  require 'profile_image_retrived.php';
  require 'home_script_data_submit.php';
  require 'retrive_location.php';
  require 'retrive_gender.php';
  
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
    <link rel ='stylesheet' href='http://localhost/sn/css/site_header_v1.css'/>
    <link rel='stylesheet' type='text/css' href='http://localhost/sn/css/home/cell.css'/>
    <link rel ='stylesheet' href='http://localhost/sn/css/home/home_stylesheet_1081.css'/>
    <link rel ='stylesheet' href='http://localhost/sn/css/home/home_stylesheet_1081_sub_1.css'/>
    <link rel ='stylesheet' href='http://localhost/sn/css/home/home_stylesheet_800.css'/>
    <link rel ='stylesheet' href='http://localhost/sn/css/home/home_stylesheet_450.css'/>
    <link rel ='stylesheet' href='http://localhost/sn/css/home/home_stylesheet_321.css'/>
	<link rel='stylesheet' href='http://localhost/sn/css/home/trend_graph_stylesheet.css'>
    <link rel='stylesheet' href='http://localhost/sn/css/home/new_frame.css'>
    
    
    <script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
    <script type='text/javascript' src='http://localhost/sn/js/responsive_header_ui.js'></script>
	<script type='text/javascript' src='http://localhost/sn/js/home/n_f_reminder.js'></script>
    <script type='text/javascript' src='http://localhost/sn/js/home/content_responsive_ui.js'></script>
    <script type='text/javascript' src='http://localhost/sn/js/home/jquery_home.js'></script>
    <script type='text/javascript' src='http://localhost/sn/js/home/get_data_trending_ajax.js'></script>
    <script type='text/javascript' src='http://localhost/sn/assets/plug-ins/js/plugin_elstc.js'></script>
    <script type='text/javascript' src='http://localhost/sn/js/home/chat.js'></script>
    <script type='text/javascript' src='http://localhost/sn/js/home/qs_ajax_handler.js'></script>
	<script type='text/javascript' src='http://localhost/sn/js/home/q_chat_handler.js'></script>
    <script type='text/javascript'>
      var closeIFrame = function() {
	      $("#iframe_content_wrapper").hide();
          $('.new_frame').remove();
		  
      };
    </script>
  </head>
  <body>
	<div class='header' id='header'>
		<div class='header_content_wrapper'>
			<div class='header_content_wrapper_inner'>
				<ul class='header_items'>
				  <div class='header_user_data_inline_block_0'>
					<li class='nav_li_log_out'>
						<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-power-off' style='color:#779FC3;font-size:1.1em;line-height:45px'></i><span class='a_span'>Exit</span></a></strong> 
					</li>
					<li class='nav_bar'>
						<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-list' style='color:#779FC3;font-size:1.1em;line-height:45px'></i><span class='a_span'>Navigation</span></a></strong>
					</li>
					<li>
              <strong><a href='http://localhost/sn/notifications.php' id='hyperlink_notification'><i class='fa pull-left  fa-bell' style='color:#779FC3;font-size:1.1em;line-height:45px' id='n_f_icon'></i><span class='a_span'>Alerts</span></a></strong>
					</li>
				</div>
				</ul>
				<ul class='header_user_data'>
				  <div class='header_user_data_inline_block_1'>
					<li class='image_data'>
						<a href='http://localhost/sn/php/home/uploadphoto.php'><div class='user_retrived_img_container' style='background-image:url(<?php echo $avater_path ?>)'>
						</div></a>
					</li>
					<li class='text_data'>
						<strong>
							<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
								<i class='fa pull-left  fa-user' style='color:#1B5E1D;font-size:2em;line-height:60px' id='avater_head'></i>
								<?php  
									echo $user_name_retrived;
								?>
							</a>
						</strong>
					</li>
				  </div>
				</ul>
			</div>
		</div>
	</div>
    <div class='main_body_wrapper'>
      <input type='hidden' id='query_id_final' value='5'/>
      <div class='inner_body_wrapper'>
        <section class='section_0'>
          <div class='inner_section_0'>
            <div class='sec_0_sub_el'>
              <ul><li class='first_el'><strong><i class='fa fa-user-plus' style='color:#1B5E1D;margin-right:3px'></i><a href='#'>Invite People</a></strong></li></ul>
            </div>
            <div class='u_img_container'>
              <div class='u_img_container_inner' style='background-image:url(<?php echo $avater_path ?>)'>
                <form action='home.php' method='post' enctype='multipart/form-data'>
                  <input type='file' id='user_profile_img_browse' name='img_avatar'/>
                  <p class='browse_image_button_wrapper'><input type='submit' value='browse' id='user_profile_img_post' name='user_profile_img_post'/></p>
                </form>
              </div>
              <!-- <img></img>-->
            </div>
            <div class='user_info_view'>
              <div class='location_info'>
                <div><p><span class='update_location_on_click' id='update_location_on_click'><i class='fa fa-pull-left fa-map-marker' style='color:#DC403B;line-height:16px'></i><?php echo $retrived_location  ?></span></p></div>
              </div>
              <div class='gender_info'>
                <div><p><span class='update_gender_on_click' id='update_gender_on_click'><i class='fa fa-pull-left fa-<?php  echo strtolower($retrive_gender)?>' style='color:#DE593A;line-height:16px'></i><?php  echo $retrive_gender ?></span></p></div>
              </div>
            </div>
            <div class='side_nav_container_1'>
              <ul>
                <li><strong><i class='fa fa-user-plus' style='width:15px;color:#1B5E1D;margin-right:3px;'></i><a href='http://localhost/sn/invitefriends.php'>Invite Friends</a></strong></li>
                <li><strong><i class='fa fa-wrench' style='width:15px;color:#DB280E;margin-right:3px;'></i><a href='http://localhost/sn/settings.php'>Settings</a></strong></li>
                <li><strong><i class='fa fa-question-circle' style='width:15px;color:#3F3CFD;margin-right:3px'></i><a href='http://localhost/sn/faq.php'>Faq</a></strong></li>
              </ul>
            </div>
            <div class='side_nav_container_2'>
              <ul>
                <li><strong><i class='fa fa-info-circle' style='width:15px;color:#3F3CFD;margin-right:3px'></i><a href='http://localhost/sn/about.php'>About Us</a></strong></li>
                <li><strong><i class='fa fa-check-square' style='width:15px;color:#9F2502;margin-right:3px'></i><a href='http://localhost/sn/terms&conditions.php'>Terms & Conditions</a></strong></li>
	            <li><strong><i class='fa fa-check-square' style='width:15px;color:#9F2502;margin-right:3px'></i><a href='http://localhost/sn/privacypolicy.php'>Privacy</a></strong></li>
                <li><strong><i class='fa fa-envelope' style='width:15px;color:#2F7CFE;margin-right:3px'></i><a href='http://localhost/sn/feedback.php'>Feedback</a></strong></li>
              </ul>
            </div>          
          </div>
        </section>
        <section class='section_1'>
          <div class='global_search_container_wrapper'>
            <div class='db_qurey_box_wrapper'>
              <form action='home.php' method='post' enctype='multipart/form-data'>
                <div class='form_wrapper'>
                  <div class='input_group_primary'>
                    <input type='text' name='sf_input' id='search_bar_input' placeholder='wildcard'/>
                  </div>
                  <div class='input_group_secondary'>
                    <textarea id='search_bar_input_tweet' name='message' placeholder='add a message..[optional]'></textarea>
                    <div class='image_picker_wrapper'>
                      <input type='file' class='image_picker' name='image_picker' id='image_picker'/>
                    </div>
                    
                    <div class='g_s_c_ul'>
                      <ul>
                        <li><i class='fa pull-left  fa-camera' style='color:#9a9a9a;padding:0.5em' id='image_picker_button_browse'></i></li>
                        <!--<li class='smily_picker_browse'><i class='fa pull-left  fa-smile-o' style='color:#9a9a9a;padding:0.5em'></i></li>-->
                        <li class='sub_li'><input type='submit' name='sf_data' id='sf_data' value='Done'/></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class='chell_container_outer'>
            <div class='anime_preload_1'></div>
            <div class='chell_container_inner'>
              <?php  
                  require 'home_script_dom_ready.php';  
              ?>
            </div>
            <center>
				<div id='load' class='load'>
				    <?php 
                        require 'pagination_index.php'; 
		             ?>   
				</div>
			</center>
          </div>

				
        </section>
        <section class='section_2'>
          <div class='section_2_outer'>
            <div class='section_2_inner'>
              <div class='sec_2_header_container'>
                <h1><i class='fa fa-line-chart' style='color:#7D81FE;margin-right:3px'></i>Trending Right now</h1>
              </div>
			<?php
			  require 'trend_graph_data.php';
			?>
            </div>   
          </div>
        </section>
        <section class='section_3'>
          <div class='section_3_outer'>
            <div class='section_3_inner'>
              <div class='section_3_header_container'>
                <h1><i class='fa fa-gears' style='color:#35404F;margin-right:3px;text-shadow:0px 0px 5px white'></i>Quick Settings</h1>
              </div>
              <div class='sec_3_menu_items'>
                <ul>
                  <li><strong id='user_name_update_quick'><i class='fa fa-edit' style='color:#3F3CFD;margin-right:3px'></i>Change username</strong></li>
                  <li><strong><i class='fa fa-microphone' style='color:#FF2E3E;margin-right:3px'></i>Enable Voice Commands</strong></li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
    <div class='iframe_content_wrapper' id='iframe_content_wrapper'>
      <div class='iframe_content_inner'>
        <!--<iframe class='new_frame' name='new_frame'>
        </iframe>-->
      </div>
    </div>
      <div class='quick_settings_wrapper' id='quick_settings_wrapper'>
        <div class='quick_settings_wrapper_inner'>
          <div class='quick_settings_wrapper_inner_content_layer'  >
            <form action='home.php' method='post'>
              <div class='header_space_name' id='header_space_name'>
                  <h4 class='form_header'>Choose an username<i class='fa fa-pull-right fa-close' id='exit_quick_settings_b1'></i></h4>
              </div>
              <div class='header_space_location' id='header_space_location'>
                   <h4 class='form_header'>Set Your Location<i class='fa fa-pull-right fa-close' id='exit_quick_settings_b2'></i></h4>
              </div>
              <div class='header_space_gender' id='header_space_gender'>
                   <h4 class='form_header'>Edit Gender<i class='fa fa-pull-right fa-close' id='exit_quick_settings_b3'></i></h4>
              </div>
              <div class='on_load' id='on_load'></div>
               <p id='on_sucess_data'></p>
               <p id='on_error_data'></p>
              <div class='update_space_name' id='update_space_name'>
              <p><input type='text' name='name_update_picker' class='name_update_picker' id='name_update_picker'/></p>
              <p><input type='button' name='name_update_picker_post' class='name_update_picker_post' value='Update Name' id='name_update_picker_post'/></p>
              </div>
              <div class='update_space_location' id='update_space_location'>
                <p><input type='text' name='location_update_picker' class='location_update_picker' id='location_update_picker'/></p>
                <p><input type='button' name='location_update_picker_post' class='location_update_picker_post' value='Update Location' id='location_update_picker_post'/></p>
              </div>
              <div class='update_space_gender' id='update_space_gender'>
                <select name='gender_update_picker' class='gender_update_picker' id='gender_update_picker'>
                  <option class='gender_options' id='gender_options' value='male'>Male</option>
                  <option class='gender_options' id='gender_options' value='female'>female</option>
                </select>
                <p><input type='button' name='gender_update_picker_post' class='gender_update_picker_post' value='Update gender' id='gender_update_picker_post'/></p>
              </div>
              
            </form>
          </div>
        </div>
      </div>
	  <div class='q_chat_wrapper'>
	    <div class='q_chat_wrapper_inner'>
		    <div class='chat_header'>
			    <input type='hidden' value='<?php echo $user_primary_id_retrived ?>' id='f_e_data'/>
			</div>
		</div>
	  </div>
	 <div class='notification_wrapper' id='notification_wrapper' style='display:none' >
	    <div class='notification_content' style='display:table-row'>
		    <h3 style='padding:5px;text-align:center;border-bottom:1px solid #ccc;font-size:12px;line-height:20px;color:#0E3B37'>Notice Board</h3>
		    		<ul style='padding:8px;margin:0px;width:98%' id='notification_content_ul'>
							<?php
							    //require '../notification_script.php';
							 ?>
					
				    </ul>	
		</div>
	 </div>
  </body>
</html>


