<?php
	
	if(isset($_GET['i'])){
		$p_i=$_GET['i'];
		if(!empty($pagination_num_page_total)){
			$x;
			for($x=1;$x<=$pagination_num_page_total;$x++){
				echo"<a href='http://localhost/sn/php/home/home.php?p_n=$x&i=$p_i'>$x</a>";
				
			}
			}else{
			
			
		}
		
		}else{
		if(!empty($pagination_num_page_total)){
			$x;
			for($x=1;$x<=$pagination_num_page_total;$x++){
				echo"<a href='http://localhost/sn/php/home/home.php?p_n=$x'>$x</a>";
				
			}
			}else{
			
			
		}
	}
?>