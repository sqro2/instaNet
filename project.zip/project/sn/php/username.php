<?php
 require 'home/query_user_session.php';
 require 'db_connect.php';
 $user_name_retrive=$dbconnect->query("SELECT id,username FROM users WHERE session_info='$u_primary_data'");
 while($row=$user_name_retrive->fetch()){
	 $user_name_retrived=$row['username'];
	 $user_primary_id_retrived=$row['id'];
	 
	 }

?>
