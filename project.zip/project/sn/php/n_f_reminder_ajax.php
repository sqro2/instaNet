<?php
	session_start();
	require 'username.php';
 		$bool=0;
		$n_f_r_q_a_1=$dbconnect->query("SELECT * FROM chat_notice WHERE notice_to='$user_primary_id_retrived' AND read_yet='$bool' ");
		$c=$n_f_r_q_a_1->rowCount();
		echo $c;
?>