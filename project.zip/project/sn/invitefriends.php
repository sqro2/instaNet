<!doctype html>
<?php 
	session_start();
	require './php/home/query_user_session.php';
	require './php/db_connect.php';
	require './php/username.php';
	require './php/home/profile_image_retrived.php';
	$inv_id=$u_primary_data.mt_rand(999,2147483322);
	$ref_links_query_referrer=$dbconnect->query("SELECT * FROM ref_links WHERE referrer='$u_primary_data'");
	$ref_links_row_count=$ref_links_query_referrer->rowCount();
	if($ref_links_row_count==0){
		$link_content="http://localhost/sn/user_log_in.php?inv_id=$inv_id";
		$ref_links_insert_data=$dbconnect->prepare("INSERT INTO ref_links (referrer,link_content,inv_id) VALUES(:referrer,:link_content,:inv_id)");
		$ref_links_insert_data->bindValue(':referrer',$u_primary_data);
		$ref_links_insert_data->bindValue(':link_content',$link_content);
		$ref_links_insert_data->bindValue(':inv_id',$inv_id);
		$ref_links_insert_data->execute();
		header("location: http://localhost/sn/invitefriends.php");
	}
	if($ref_links_row_count>=0){
		$ref_links_retrive_data=$dbconnect->query("SELECT * FROM ref_links WHERE referrer='$u_primary_data'");
		foreach($ref_links_retrive_data->fetchAll() as $row){
			$retrive_link_content=$row['link_content'];
		}
	}
	
?>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0'>
		<title>Invite Friends</title>
		<link rel='stylesheet' type='text/css' href='http://localhost/sn/css/font-awesome/css/font-awesome.min.css'/>
		<link rel="stylesheet" href="http://localhost/sn/css/i_f_stylesheet.css">
		<script type='text/javascript' src='http://localhost/sn/js/jquery.js'></script>
		<script type='text/javascript' src='http://localhost/sn/js/nav_i_f.js'></script>
	</head>
	<body>
		<div class='header'>
			<div class='header_content_wrapper'>
				<div class='header_content_wrapper_inner'>
					<ul class='header_items'>
						<li class='nav_li_log_out'>
							<strong><a href='http://localhost/sn/home/logout.php'><i class='fa pull-left  fa-hourglass-end' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>logout</span></a></strong> 
						</li>
						<li class='nav_bar'>
							<strong><a href='http://localhost/sn/about.php'><i class='fa pull-left  fa-bars' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>nav_menu</span></a></strong>
						</li>
						<li>
							<strong><a href='http://localhost/sn/notifications.php'><i class='fa pull-left  fa-bell' style='color:#E8F1FA;font-size:1.1em;line-height:40px'></i><span class='link_style'>notification</span></a></strong>
						</li>
					</ul>
					<ul class='header_user_data'>
						<li class='image_data'>
							<div class='user_retrived_img_container' style='background-image:url(<?php echo $avater_path ?>)'>
							</div>
						</li>
						<li class='text_data'>
							<strong>
							<a href='http://localhost/sn/php/home/home.php' style='text-decoration:none'>
							      <?php echo $user_name_retrived; ?>
							</a></strong>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class='content_wrapper_outer'>
			<div class='content_wrapper_inner'>
				<div class='section_0'>
					<div class='ul_nav_container'>
						<div class='ul_nav'>
							<ul>
								<h1 class='ul_header'>Info-Bar</h1>
								<li>
									<strong>
										<a href='http://localhost/sn/settings.php'>Settings</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/about.php'>About</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/faq.php'>FAQ</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/privacypolicy.php'>
											
										Privacy</a>
									</strong>
								</li>
								<li>
									<strong>
										<a href='http://localhost/sn/terms&conditions.php'>Terms & Conditions</a>
									</strong>
								</li>
								<li class='li_feedback'>
									<strong >
										<a href='http://localhost/sn/feedback.php'>Feedback</a>
									</strong>
								</li>							 
							</ul>
						</div>
					</div>
				</div>
				<div class='section_1'>				 
					<div class='inner_section_1'>
						<div class='page_heading'>
							<h1 id='h_content'>
								Invite your friends 
								<span class='h_content_span_el_1' id='h_content_span_child_1'><a href='http://localhost/sn/settings.php'>Settings</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/about.php'>About</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/faq.php'>FAQ</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/privacypolicy.php'>Privacy Policy</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/terms&conditions.php'>Terms</a></span>
								<span class='h_content_span_el_1'><a href='http://localhost/sn/feedback.php'>feedback</a></span>								
								</h1>
						</div>
						<div class='article'>
							<div class='article_content'>
								You can invite your friends to join you.Just copy the link and send it to your friends whenever they log in to Thrill you will get a notification and you will be able to connect with them instantly.						 
							</div>
							<div class='link_data'>
								<label for='ref_link'>Here's the link</label>
								<input type='text' class='ref_link_copied' value='<?php echo $retrive_link_content;  ?>' />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>				
