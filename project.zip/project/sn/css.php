<?php
  require 'pri_algorithm.php';
	
	
	$html_doc=
	"<!DOCTYPE html>
	<head>
	
	</head>
	<body>
	
	<form action='http://localhost/sn/css.php' method ='post'>
	<textarea rows='20' cols='40' name='var_str'></textarea>
	<br>
	     <input type='radio' name='css_selector_0' value='0' checked>Class
	     <input type='radio' name='css_selector_1' value='1'>Id
	    <input type='submit' value='submit' name='sub'/>
	</form>
	</body>";
	echo $html_doc;
	
	
	
	
?>
